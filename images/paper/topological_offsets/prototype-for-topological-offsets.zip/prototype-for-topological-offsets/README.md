# Wildmeshing's prototype for a new feature 
prototype for [wildmeshing](https://github.com/wildmeshing/wildmeshing-toolkit)

## Table

- [Wildmeshing's prototype for a new feature](#wildmeshings-prototype-for-a-new-feature)
  - [Table](#table)
  - [Dataset](#dataset)
  - [User Guidance](#user-guidance)
  - [Pipeline](#pipeline)
  - [Current Plan](#current-plan)
  - [Current Result](#current-result)
  - [Remeshing Summary](#remeshing-summary)
    - [~~Split Process On The Interior Area~~](#split-process-on-the-interior-area)
    - [~~Swap/Flip Tradegies~~](#swapflip-tradegies)
    - [Projection Process](#projection-process)

## Dataset
please check the ./voronoi_dataset/DataSet/ to find them. there are two types of them, .obj and .hdf. the inflation is the input's inflation result, and the padding is the rectangle substract the input's inflation result.

## User Guidance
|       |                                                                                                                                                                                                                                                                                                                                                                                                        |
| ----- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| step1 | line setting: you should use bottom2 to switch to line-drawing mode and click the plane to have several points, these points will be a series of segments.                                                                                                                                                                                                                                             |
| step2 | do inflation: you should press bottom2 again, and press bottom1 to compute. then you are supposed to get a final result. inner lines are connected with red lines. it is same for inflation segments. inflation points are red and original input points are blue, other interpolation points along with inner edges are green. Meanwhile, a vtk. file should be generated in your computer with (D:/) |
| step3 | remeshing: for now, remeshing will immediately be done after inflation, maybe I will set an independent bottom for this operation later.                                                                                                                                                                                                                                                               |
| step4 | optimization: THIS PART IS UNDER CONSTRUCTION                                                                                                                                                                                                                                                                                                                                                          |
| step5 | reset: you could press bottom3(bottom3's function is not checked currently, so it might to occur errors.) to reset this program.                                                                                                                                                                                                                                                                       |

## Pipeline

| stage         | details                                                                                                                                                                                                                                         |
| ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| triangulation | maybe do it with a low resolution, since our program can work with a triangulation with any resolution. please see the next inflation                                                                                                           |
| inflation     | should consider the case that higher dimensional simplex is not anotated but its incident's low dimensional simplex does, we should do addtional split operations for this situation, then the resolution of the triangulation is not a problem |
| remeshing     | UNDER CONSTRUCTION                                                                                                                                                                                                                              |

## Current Plan
- do a 2D version prototype
  - [x] user self-defined line 
  - [x] do trianglization 
  - [x] inflation
  - - [x] debug the current algorithm
  - - - Problems: for an face with three anotated vertices, an addtional split is required if this face is not anotated. this situation also works to the 3D world, when the surface created really small cavities.
  - [x] remeshing
  - - [x] implement basic operations
  - - [x] test the remeshing function
  - - [x] remeshing, seperate the inner and the outer areas(for exterior part, do remeshing, for interior part, just to flip/swap)
  - - [x] compare directly using triangulation 
  - - - Current Conclusion: ~~might work, you can use Carve got from previous inflation(function getResultCurve in the main.cpp), then do a triangulation operation, but it seems to be unstable?~~ this would be complicated and tricky, so just do remeshing.
  - - [x] project the offset on the input
  - [x] optimization
  - - [x] basic offset optimization
  - [ ] simulation test
  - - [x] dataset

- improvement
  - [x] inflation boundary line is not obvious, need to adjust the width of the line 
  - [x] write more comments, make the code more readable 
  - [x] generate output which could be check with Paraview
  - - [x] more tag should be added in vtk. format *plus:wait to use the paraviewo
  - [ ] reconstruct the code, make the project's code more readable, extract class Remeshing and Inflation, maybe I will do it later.
  - [ ] reduce the complexity of the algorithm(edge-searching related), this work might to be solved when this project is transferred to the wildmeshing toolkits. for now, this part's prority is low.

## Current Result

| inflation rate | the inflation rate is based on the average length of the scaffold                |
| -------------- | -------------------------------------------------------------------------------- |
| 10%            | <img decoding="async" src="./image/inflation0_1.png" width="80%" align="center"> |
| 50%            | <img decoding="async" src="./image/inflation0_5.png" width="80%" align="center"> |
| 100%           | <img decoding="async" src="./image/inflation1_0.png" width="80%" align="center"> |
| 200%           | <img decoding="async" src="./image/inflation2_0.png" width="80%" align="center"> |
| 500%           | <img decoding="async" src="./image/inflation5_0.png" width="80%" align="center"> |

| previous skeleton description |                                                                                                                                                                                                                                                       |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| original_describe             | <img decoding="async" src="./image/triangulization_detail.png" width="80%" align="center">                                                                                                                                                            |
| triangulization               | <img decoding="async" src="./image/triangulization.png" width="80%" align="center">                                                                                                                                                                   |
| inflation                     | <img decoding="async" src="./image/inflation.png" width="80%" align="center">                                                                                                                                                                         |
| remeshing_general             | <img decoding="async" src="./image/remeshing_output.png" width="80%" align="center">                                                                                                                                                                  |  |
| remeshing_input               | <img decoding="async" src="./image/remeshing_input.png" width="80%" align="center">                                                                                                                                                                   |  |
| before remeshing              | <img decoding="async" src="./image/result_inflation.png" width="80%" align="center">                                                                                                                                                                  |  |
| after remeshing optimization  | <img decoding="async" src="./image/meanratio.png" width="80%" align="center">                                                                                                                                                                         |
|                               | NOTE: the pictures above are displayed by the libigl, you can have a closer look by using Paraview, checking the .vtk files under D:/(this is the default direction) after pressing bottom 1. Besides, please don't export the file while opening it. |

## Remeshing Summary

this block reported some problem I found during remeshing part's code work. you can find this mesh in the "output" file.

### ~~Split Process On The Interior Area~~

this part records some specific situation on the split operations. on the pictures, I drew a personal solution for these cases. the delete operation below relates to the inflation edges' vector, so actually we won't delete the edge in the topology.

| Special Cases                                                                              |                                                                                                                                                                                                                                                                                                                                                                      |
| ------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| BLUES is the input, RED is the exterior area, WHITE is the offset                          |                                                                                                                                                                                                                                                                                                                                                                      |
| corner split case                                                                          |                                                                                                                                                                                                                                                                                                                                                                      |
| <img decoding="async" src="./image/corner1.png" width="100%" align="center">               |                                                                                                                                                                                                                                                                                                                                                                      |
| <img decoding="async" src="./image/corner1-2.png" width="100%" align="center">             | we need do addtional two split operation for the two enges on the faces but not belongs to the input.                                                                                                                                                                                                                                                                |
| interior split case                                                                        |                                                                                                                                                                                                                                                                                                                                                                      |
| <img decoding="async" src="./image/interior_split1.png" width="100%" align="center">       | first, we do a split, then deleted the offset anotation for the orange edge, then add new green edge to into the offset vector                                                                                                                                                                                                                                       |
| <img decoding="async" src="./image/interior_split2.png" width="100%" align="center">       | same as the situation above, but in this case, there are three neighbour vertices                                                                                                                                                                                                                                                                                    |
|                                                                                            | actually, I have implemented this part, I don't know if this is more better or not since it I thought the performance is not good as I assumed after applying such a modification, maybe this is because that I didn't implemented corner case? have no idea now. you can check these two .hdf files, their names are split_interior_berore and split_interior_after |
| <img decoding="async" src="./image/before_split_interior.png" width="100%" align="center"> | before                                                                                                                                                                                                                                                                                                                                                               |
| <img decoding="async" src="./image/split_interior.png" width="100%" align="center">        | after                                                                                                                                                                                                                                                                                                                                                                |




### ~~Swap/Flip Tradegies~~

I used two swap/flip methods to do remeshing. equalized valence and the mean ratio value.

I found that I made a mistake while I implenmenting the mean-ratio method, for now, the mean-ratio method has a better performance.

### Projection Process

All these problems actually more likely to happen in 3D surfaces' boundary or feature-line area.

| Problems                                                                               |                                                                                                                                                                                                                 |
| -------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| BLUES is the input, RED is the exterior area, WHITE is the offset                      |                                                                                                                                                                                                                 |
| case 1                                                                                 |                                                                                                                                                                                                                 |
| <img decoding="async" src="./image/bad projection.png" width="100%" align="center">    | projection points are not reasonable in some specific cases. this problem could be solved by using incident vertices information. but it still have a potential problem likes below.                            |
| ~~case 2~~                                                                             |                                                                                                                                                                                                                 |
| <img decoding="async" src="./image/bad projection2.png" width="100%" align="center">   | the corner situation display an another bad projection. again, this could be solved by using incident vertices information. maybe we could do a resample technique on the corner, something like doing a split. |
| <img decoding="async" src="./image/bad projection2-2.png" width="100%" align="center"> |                                                                                                                                                                                                                 |
| ~~case 3~~                                                                             |                                                                                                                                                                                                                 |
| <img decoding="async" src="./image/bad projection3.png" width="100%" align="center">   | this is quite similar to the case 1.                                                                                                                                                                            |


| ~~Solution Discussion~~ |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| idea 1                  | we can avoid it by not finding global closest simplex, just finding it in vertices' incident one-ring area                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| idea 2                  | maybe set a threshold to detect the sharp corners, then directy connect the offset vertices to the input vertices                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| idea 3                  | I thought this idea is exactly the idea mentioned in the notes, but it seems not to use the "incident" vertices directly. I remember that, in the last discussion, Daniel said there is an advantage of our project is that we can simply use the incident vertices instead of finding them by using BVH or other acceleration structure. Therefore, I thought maybe this part is still waited to be discussed. In my opinion, I had a very simple solution. I am not sure if this would work, but may be we can connect the offset points with all of its incident input's vertices, then do something like phong-normal. and these normals will be optimized in the next stage of our pipeline |