#include <igl/adjacency_list.h>
#include <catch2/catch_test_macros.hpp>
#include <embedded_remeshing/Inflation.hpp>

// V + F - E = 2 -> F = 2 + E - V
// it seems that graph and polyhadra are quite different stories when we
// want to compute the "Genus" in 2D. Some websites said that there is no
// "Genus" in graph theroy but euler theory still works here. In this case
// the region number becomes F(equal to "Genus - 1" if you see "1 loop as 1 Genus").
int getRegionNum(const Eigen::MatrixXd& V, const Eigen::MatrixXi& E)
{
    return 2 + E.rows() - V.rows();
}
int getRegionNum(const std::vector<int>& V, const std::vector<std::vector<int>>& E)
{
    return 2 + E.size() - V.size();
}
bool isExist(const std::vector<int>& list, int idx)
{
    for (const int idx_list : list) {
        if (idx_list == idx) return true;
    }
    return false;
}
bool findNext(
    const std::vector<std::vector<int>>& boundary_edges,
    const std::vector<int>& traveled,
    int& idx)
{
    for (const std::vector<int> edge : boundary_edges) {
        if (edge[0] == idx && !isExist(traveled, edge[1])) {
            idx = edge[1];
            return true;
        }
        if (edge[1] == idx && !isExist(traveled, edge[0])) {
            idx = edge[0];
            return true;
        }
    }
    return false;
}
bool isManifold(
    const Eigen::MatrixXd& V,
    const Eigen::MatrixXi& F,
    std::vector<std::vector<int>>& adj_map,
    const std::vector<int>& boundary)
{
    for (const int boundary_idx : boundary) {
        const std::vector<int>& neighbours = adj_map[boundary_idx];
        int neighbourMarkedNum = 0;
        for (const int neighbour_idx : neighbours) {
            if (isExist(boundary, neighbour_idx)) ++neighbourMarkedNum;
        }
        if (neighbourMarkedNum != 2) return false;
    }
    return true;
}
// for now, E just a loop
void generateData(Eigen::MatrixXd& V, Eigen::MatrixXi& E, int VNum = 10)
{
    V.resize(VNum, 2);
    E.resize(VNum, 2);
    srand((unsigned)time(NULL));
    for (int i = 0; i < VNum; ++i) {
        //rand()/double(RAND_MAX)
        V(i, 0) = (rand() / double(RAND_MAX) - 0.5) * 10;
        V(i, 1) = (rand() / double(RAND_MAX) - 0.5) * 10;
        E(i, 0) = i;
        E(i, 1) = (i + 1) % (VNum);
    }
}

// for now, E just a loop
void generateDataSimple(Eigen::MatrixXd& V, Eigen::MatrixXi& E)
{
    V.resize(4, 2);
    E.resize(4, 2);
    V << 0, 0, 1, 0, 1, 1, 0, 1;
    E << 0, 1, 1, 2, 2, 3, 3, 0;
}

void generateDatawithSmallTriangles(Eigen::MatrixXd& V, Eigen::MatrixXi& E)
{
    V.resize(10, 2);
    E.resize(10, 2);
    V << 3.68892, 4.69909, 3.72799, -2.02109, 3.66695, -1.08875, -1.64113, 3.15912, -1.72872,
        2.57591, 1.20228, 4.31211, 2.19108, -0.595569, 2.78527, -0.139927, -4.85534, 0.28489,
        -4.68596, 3.57936;
    E << 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 0;
}

void travel(
    const std::vector<int>& boundary,
    const std::vector<std::vector<int>>& boundary_edges,
    int& cur_idx,
    std::vector<int>& traveled,
    int& loop_num)
{
    if (findNext(boundary_edges, traveled, cur_idx)) {
        traveled.push_back(cur_idx);
        travel(boundary, boundary_edges, cur_idx, traveled, loop_num);

    } else {
        ++loop_num;
        for (int i = 0; i < boundary.size(); ++i) {
            if (!isExist(traveled, boundary[i])) {
                cur_idx = boundary[i];
                traveled.push_back(cur_idx);
                travel(boundary, boundary_edges, cur_idx, traveled, loop_num);
                break;
            }
        }
    }
}

int getLoopNums(
    const std::vector<int>& boundary,
    const std::vector<std::vector<int>>& boundary_edges)
{
    std::vector<int> traveled;
    int loop_num = 0;
    int cur_idx = boundary[0];
    traveled.push_back(cur_idx);
    travel(boundary, boundary_edges, cur_idx, traveled, loop_num);
    return loop_num;
}

//// input x,y should be within (-5,5)
//// test genus of input and compare to number of output components
// TEST_CASE("prototype-inflation", "[inflation]")
//{
//     Eigen::MatrixXd V;
//     Eigen::MatrixXi E;
//     int TEST_NUM = 1;
//     int DATA_NUM = 10;
//     SECTION("Inflation's output should be manifold")
//     {
//        for (int i = 0; i < TEST_NUM / 2; ++i) {
//            // std::cout << "HERE!!!!!!!!! "<<i << std::endl;
//            generateData(V, E, DATA_NUM);
//            Prototype proto(V, E);
//            proto.process();
//            std::vector<std::vector<int>> A;
//            igl::adjacency_list(proto.F, A);
//            REQUIRE(isManifold(proto.V, proto.F, A, proto.offset) == true);
//        }
//    }
//
//    SECTION("Inflation's output's Genus should be input's Region number")
//    {
//        for (int i = 0; i < TEST_NUM; ++i) {
//            generateData(V, E, DATA_NUM);
//            Prototype proto(V, E);
//            proto.process();
//            int R_input = getRegionNum(proto.markedV, proto.markedE);
//            int G_output = getLoopNums(proto.offset, proto.offset_edges);
//            //int G_output = getRegionNum(proto.boundary, proto.boundary_edges) / 2;
//            if (R_input != G_output) {
//                std::cout << "here is V" << V << std::endl;
//                std::cout << "here is E" << E << std::endl;
//            }
//            REQUIRE(R_input == G_output);
//        }
//    }
//}
//
// TEST_CASE("prototype-remeshing", "[remeshing][inflation]")
//{
//    Eigen::MatrixXd V;
//    Eigen::MatrixXi E;
//    generateData(V, E, 4);
//    SECTION("general test for remeshing and inflation")
//    {
//        Prototype proto(V, E);
//        proto.process();
//        proto.remesh();
//        std::vector<std::vector<int>> A;
//        igl::adjacency_list(proto.F, A);
//
//        // Remeshing's output should be manifold
//        REQUIRE(isManifold(proto.V, proto.F, A, proto.offset) == true);
//        int R_input = getRegionNum(proto.markedV, proto.markedE);
//        int G_output = getLoopNums(proto.offset, proto.offset_edges);
//
//        // Remeshing's output's Genus should be input's Region number
//        if (R_input != G_output) {
//            std::cout << "here is V" << V << std::endl;
//            std::cout << "here is E" << E << std::endl;
//        }
//        REQUIRE(R_input == G_output);
//    }
//}
//
//// it seems that the paraviewo will break when the file is opened by Paraview,
//// this would be a little annoying.
////
//// this case will have [remeshing] tag later
// TEST_CASE("prototype-paraviewo", "[paraviewo][inflation]")
//{
//     Eigen::MatrixXd V;
//     Eigen::MatrixXi E;
//     SECTION("Generate mesh after inflation")
//     {
//         generateData(V, E, 4);
//         Prototype proto(V, E);
//         proto.process();
//         proto.export_file("D:\\");
//     }
//
//    // need to check the projection P's size
//    SECTION("Generate mesh after remeshing")
//    {
//        generateData(V, E, 4);
//        Prototype proto(V, E);
//        proto.process();
//        proto.remesh();
//        proto.export_file("D:\\");
//    }
//}

//************************************************************
// Currently, my Internet is bad, therefore it is a nightmare
// to recompile the filefold, I will make the following part
// apart later
//************************************************************

TEST_CASE("prototype-triangulate", "[triangulate]")
{
    Eigen::MatrixXd V;
    Eigen::MatrixXi E;
    generateData(V, E, 4);
    Prototype proto(V, E);
    proto.process();
    REQUIRE(!proto.isInvert());
}

TEST_CASE("prototype-invert", "[operation][invert]")
{
    // set up a topology and the isInvert should work right
    Eigen::MatrixXd V(0, 2);
    Eigen::MatrixXi E(0, 2);
    Prototype proto(V, E);
    proto.V.resize(4, 2);
    proto.F.resize(3, 3);

    proto.V << 0.0, 0.0, 2.0, 0.0, 1.0, 2.0, 1.0, 1.0;
    proto.F << 0, 1, 3, 3, 1, 2, 0, 3, 2;

    REQUIRE(!proto.isInvert());
    proto.V(3, 0) = 0.0;
    REQUIRE(proto.isInvert());
}

TEST_CASE("prototype-split", "[operation][split]")
{
    Eigen::MatrixXd V(0, 2);
    Eigen::MatrixXi E(0, 2);
    Eigen::MatrixXi F(0, 3);
    generateData(V, E, 4);
    Prototype proto(V, E);
    proto.V.resize(4, 2);
    proto.F.resize(3, 3);
    proto.V << 0.0, 0.0, 2.0, 0.0, 1.0, 2.0, 1.0, 1.0;
    proto.F << 0, 1, 3, 3, 1, 2, 0, 3, 2;
    proto.updateBoundary();
    igl::edges(proto.F, proto.E);

    SECTION("general case")
    {
        // splited edges should disappear
        int newvid0 = proto.split_general(0, 3);
        int newvid1 = proto.split_general(1, 3);
        int newvid2 = proto.split_general(2, 3);
        V = proto.V;
        E = proto.E;
        F = proto.F;
        // new vertices and edges indices should be updated
        REQUIRE(V.rows() == 7);
        REQUIRE(E.rows() == 15);
        // splited edges should be shorten and on the same line
        REQUIRE((V.row(newvid0) - V.row(0)).norm() == 0.5 * (V.row(0) - V.row(3)).norm());
        REQUIRE((V.row(newvid0) - V.row(3)).norm() == 0.5 * (V.row(0) - V.row(3)).norm());
        REQUIRE((V.row(newvid0) - V.row(0)).dot(V.row(newvid0) - V.row(3)) < 0);


        REQUIRE((V.row(newvid1) - V.row(1)).norm() == 0.5 * (V.row(1) - V.row(3)).norm());
        REQUIRE((V.row(newvid1) - V.row(3)).norm() == 0.5 * (V.row(1) - V.row(3)).norm());
        REQUIRE((V.row(newvid1) - V.row(1)).dot(V.row(newvid1) - V.row(3)) < 0);

        REQUIRE((V.row(newvid2) - V.row(2)).norm() == 0.5 * (V.row(2) - V.row(3)).norm());
        REQUIRE((V.row(newvid2) - V.row(3)).norm() == 0.5 * (V.row(2) - V.row(3)).norm());
        REQUIRE((V.row(newvid2) - V.row(2)).dot(V.row(newvid2) - V.row(3)) < 0);
        // the result should be non-invert
        REQUIRE(!proto.isInvert());
    }

    SECTION("boundary case")
    {
        // splited edges should disappear
        int newvid0 = proto.split_boundary(0, 1);
        int newvid1 = proto.split_boundary(1, 2);
        int newvid2 = proto.split_boundary(2, 0);
        V = proto.V;
        E = proto.E;
        F = proto.F;
        // new vertices and edges should be updated
        REQUIRE(V.rows() == 7);
        REQUIRE(E.rows() == 12);
        // splited edges should be shorten and on the same line
        REQUIRE((V.row(newvid0) - V.row(1)).norm() == 0.5 * (V.row(0) - V.row(1)).norm());
        REQUIRE((V.row(newvid0) - V.row(0)).norm() == 0.5 * (V.row(0) - V.row(1)).norm());
        REQUIRE((V.row(newvid0) - V.row(0)).dot(V.row(newvid0) - V.row(1)) < 0);


        REQUIRE((V.row(newvid1) - V.row(1)).norm() == 0.5 * (V.row(1) - V.row(2)).norm());
        REQUIRE((V.row(newvid1) - V.row(2)).norm() == 0.5 * (V.row(1) - V.row(2)).norm());
        REQUIRE((V.row(newvid1) - V.row(1)).dot(V.row(newvid1) - V.row(2)) < 0);

        REQUIRE((V.row(newvid2) - V.row(2)).norm() == 0.5 * (V.row(0) - V.row(2)).norm());
        REQUIRE((V.row(newvid2) - V.row(0)).norm() == 0.5 * (V.row(0) - V.row(2)).norm());
        REQUIRE((V.row(newvid2) - V.row(2)).dot(V.row(newvid2) - V.row(0)) < 0);
        // the result should be non-invert
        REQUIRE(!proto.isInvert());
    }
}

TEST_CASE("prototype-collapse", "[operation][collapse]")
{
    Eigen::MatrixXd V(0, 2);
    Eigen::MatrixXi E(0, 2);
    generateData(V, E, 4);
    Prototype proto(V, E);
    proto.V.resize(4, 2);
    proto.F.resize(3, 3);
    proto.V << 0.0, 0.0, 2.0, 0.0, 1.0, 2.0, 1.0, 1.0;
    proto.F << 0, 1, 3, 3, 1, 2, 0, 3, 2;
    proto.updateBoundary();
    igl::edges(proto.F, proto.E);

    SECTION("general case")
    {
        REQUIRE(proto.collapse(3, 0, 10.0));
        // collapsed edges should be deleted
        REQUIRE(proto.E.rows() == 3);
        // collapsed result should be non-invert
        REQUIRE(!proto.isInvert());
    }

    SECTION("boundary case")
    {
        // boundary edges shouldn't be collapsed
        REQUIRE(!proto.collapse(0, 1, 10.0));
        REQUIRE(!proto.collapse(1, 2, 10.0));
        REQUIRE(!proto.collapse(2, 0, 10.0));
    }
}

TEST_CASE("prototype-flip", "[operation][flip]")
{
    Eigen::MatrixXd V(0, 2);
    Eigen::MatrixXi E(0, 2);
    generateData(V, E, 4);
    Prototype proto(V, E);
    proto.V.resize(4, 2);
    proto.F.resize(2, 3);
    proto.V << 0.0, 1.0, 3.0, 0.0, 6.0, 1.0, 3.0, 2.0;
    proto.F << 0, 1, 3, 3, 1, 2;
    proto.updateBoundary();
    igl::edges(proto.F, proto.E);

    SECTION("mean-ratio quality computation")
    {
        // the quality computation value should be correct
        double value0 = proto.get_mean_ratio_vaule(0, 2, 3, 1);
        double value1 = proto.get_mean_ratio_vaule(1, 3, 0, 2);
        REQUIRE(value0 < value1);
    }

    SECTION("equalized computation")
    {
        int newvid = proto.split_general(1, 3);
        REQUIRE(proto.target_valence(newvid) == 6);
        REQUIRE(proto.target_valence(0) == 4);
        REQUIRE(proto.target_valence(1) == 4);
        REQUIRE(proto.target_valence(2) == 4);
        REQUIRE(proto.target_valence(3) == 4);
    }

    SECTION("general case")
    {
        int v0, v2, e_size;
        v0 = 1;
        v2 = 3;
        e_size = E.rows();
        proto.flip(v0, v2);
        REQUIRE(e_size == E.rows());
        REQUIRE(v0 == 2);
        REQUIRE(v2 == 0);
        proto.flip(v0, v2);
        REQUIRE(e_size == E.rows());
        REQUIRE(v0 == 3);
        REQUIRE(v2 == 1);
    }
}