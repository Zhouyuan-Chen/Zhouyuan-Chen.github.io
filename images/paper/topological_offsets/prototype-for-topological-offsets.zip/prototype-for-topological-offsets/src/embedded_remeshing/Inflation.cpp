#include "Inflation.hpp"

// At least one cpp file is required so that CMake knows that this is a cpp lib.

void Prototype::process(RESOLUTION_LEVEL level)
{
    triangulate(level);
    inflate();
}

void Prototype::triangulate(RESOLUTION_LEVEL level)
{
    Eigen::MatrixXd H;
    H.resize(1, 2);
    H << 10, 0;
    Eigen::MatrixXd tempV;
    Eigen::MatrixXi tempE;
    tempV = V;
    tempE = E;
    if (level == HIGH)
        igl::triangle::triangulate(tempV, tempE, H, "a0.05q", V, F);
    else if (level == MED)
        igl::triangle::triangulate(tempV, tempE, H, "a0.5q", V, F);
    else
        igl::triangle::triangulate(tempV, tempE, H, "a0.1q", V, F);

    // need to connect the topology
    // it would be easy, just check each edge and then move on
    std::vector<std::vector<int>> A;
    // igl::adjacency_list(F, A);
    getAdjList(A);

    std::vector<std::vector<int>> tempEmarked;
    std::vector<int> tempVmarked;
    for (const auto& e : markedE) {
        int vid0 = e[0], vid1 = e[1];
        Eigen::Vector2<double> p0, p1, dir;
        p0 << V(vid0, 0), V(vid0, 1);
        p1 << V(vid1, 0), V(vid1, 1);
        int cur_vid = vid0;
        tempVmarked.push_back(cur_vid);
        while (cur_vid != vid1) {
            Eigen::Vector2<double> cur_p;
            cur_p << V(cur_vid, 0), V(cur_vid, 1);
            dir = (p1 - cur_p).normalized();
            std::vector<int>& neighbour_v_list = A[cur_vid];
            double value_dir = -1;
            int next_vid = -1;
            for (const auto neighbour_id : neighbour_v_list) {
                Eigen::Vector2<double> p, cur_dir;
                p << V(neighbour_id, 0), V(neighbour_id, 1);
                cur_dir = (p - cur_p).normalized();
                if (value_dir < cur_dir.dot(dir)) {
                    value_dir = cur_dir.dot(dir);
                    next_vid = neighbour_id;
                }
            }
            int vid0_ = cur_vid, vid1_ = next_vid;
            if (vid0_ > vid1_) std::swap(vid0_, vid1_);
            std::vector<int> newedge;
            newedge.push_back(vid0_);
            newedge.push_back(vid1_);
            tempEmarked.push_back(newedge);
            tempVmarked.push_back(next_vid);
            cur_vid = next_vid;
        }
    }
    std::sort(tempVmarked.begin(), tempVmarked.end());
    tempVmarked.erase(std::unique(tempVmarked.begin(), tempVmarked.end()), tempVmarked.end());
    markedE = tempEmarked;
    markedV = tempVmarked;

    // this block is used to fix the potential problem
    for (int i = 0; i < F.rows(); ++i) {
        int vid0 = F(i, 0), vid1 = F(i, 1), vid2 = F(i, 2);
        if (isMarked(vid0) && isMarked(vid1) && isMarked(vid2)) {
            splitface(i);
        }
    }

    // record the original triangulated topology
    V2 = V;
    F2 = F;
}

void Prototype::inflate()
{
    offset.clear();
    std::vector<std::vector<int>> A;

    // pass1 find all edges need to be operate, then do split operation
    igl::edges(F, E);
    int E_size = E.rows();
    for (const int marked_vid : markedV) {
        // igl::adjacency_list(F, A);
        getAdjList(A);
        const int& id = marked_vid;
        const std::vector<int>& neighbours = A[id];
        for (const int neighbourid : neighbours) {
            if (isMarked(neighbourid) && !isMarked(neighbourid, id)) {
                split(marked_vid, neighbourid, GENERAL);
            }
        }
    }

    igl::edges(F, E);
    for (const int marked_vid : markedV) {
        // igl::adjacency_list(F, A);
        getAdjList(A);
        const int& id = marked_vid;
        const std::vector<int>& neighbours = A[id];
        for (const int neighbourid : neighbours) {
            if (!isMarked(neighbourid) && !isMarked(marked_vid, neighbourid) &&
                !onOffset(neighbourid)) {
                int new_offset = split(marked_vid, neighbourid, GENERAL);
                offset.push_back(new_offset);
            }
        }
    }

    // finally, connect every inflation point, since each inflation point is near original point
    // we can easily get interior area.
    // connect offset
    connectOffset();
}

bool Prototype::isMarked(int idx)
{
    for (const int vid : markedV) {
        if (vid == idx) return true;
    }
    return false;
}

bool Prototype::isMarked(int vid0, int vid1)
{
    if (vid0 > vid1) std::swap(vid0, vid1);
    for (const auto& edge : markedE) {
        if (edge[0] == vid0 && edge[1] == vid1) return true;
    }
    return false;
}

void Prototype::connectOffset()
{
    std::vector<std::vector<int>> A;
    // igl::adjacency_list(F, A);
    getAdjList(A);
    for (const int b : offset) {
        const std::vector<int>& neighbours = A[b];
        for (const int neighbour : neighbours) {
            if (onOffset(neighbour)) {
                int vid0 = b, vid1 = neighbour;
                if (vid0 > vid1) std::swap(vid0, vid1);
                if (!onOffset(vid0, vid1)) {
                    std::vector<int> newedge;
                    newedge.push_back(vid0);
                    newedge.push_back(vid1);
                    offset_edges.push_back(newedge);
                }
            }
        }
    }
}

void Prototype::updateBoundary()
{
    // igl::edge_topology
    igl::edges(F, E);
    Eigen::MatrixXi EV, FE, EF;
    igl::edge_topology(V, F, EV, FE, EF);
    boundary_edges.clear();
    for (int i = 0; i < E.rows(); ++i) {
        int vid1 = E(i, 0);
        int vid2 = E(i, 1);
        if (vid1 < vid2) std::swap(vid1, vid2);
        int edge_id = -1, vid3 = -1, vid4 = -1, fid1 = -1, fid2 = -1;
        // find edge_id
        for (int i = 0; i < EV.rows(); ++i) {
            int ev0 = EV(i, 0), ev1 = EV(i, 1);
            if (ev0 <= ev1) std::swap(ev0, ev1);
            if (ev0 == vid1 && ev1 == vid2) {
                edge_id = i;
                break;
            }
        }
        assert(edge_id >= 0);
        fid1 = EF(edge_id, 0);
        fid2 = EF(edge_id, 1);
        if (fid1 == -1 || fid2 == -1) {
            if (vid1 > vid2) std::swap(vid1, vid2);
            boundary_edges.push_back(std::pair<int, int>(vid1, vid2));
        }
    }
}

bool Prototype::onBoundary(int vid0)
{
    for (int i = 0; i < boundary_edges.size(); i++) {
        if (vid0 == boundary_edges[i].first) return true;
        if (vid0 == boundary_edges[i].second) return true;
    }
    return false;
}

bool Prototype::onBoundary(int vid0, int vid1)
{
    if (vid0 > vid1) std::swap(vid0, vid1);
    for (int i = 0; i < boundary_edges.size(); i++) {
        if (vid0 == boundary_edges[i].first && vid1 == boundary_edges[i].second) return true;
    }
    return false;
}

void Prototype::getAdjList(std::vector<std::vector<int>>& adjs_list)
{
    adjs_list.clear();
    igl::edges(F, E);
    for (int i = 0; i < V.rows(); ++i) {
        std::vector<int> adjs;
        adjs_list.push_back(adjs);
    }

    for (int i = 0; i < E.rows(); ++i) {
        adjs_list[E(i, 0)].push_back(E(i, 1));
        adjs_list[E(i, 1)].push_back(E(i, 0));
    }
}

void Prototype::getAdjFaces(std::vector<std::vector<int>>& adjs_list)
{
    adjs_list.clear();
    for (int i = 0; i < V.rows(); ++i) {
        std::vector<int> adjs;
        adjs_list.push_back(adjs);
    }

    for (int i = 0; i < F.rows(); ++i) {
        adjs_list[F(i, 0)].push_back(i);
        adjs_list[F(i, 1)].push_back(i);
        adjs_list[F(i, 2)].push_back(i);
    }
}

bool Prototype::onTheSameFace(
    const std::vector<std::vector<int>>& adjs_list,
    int tar_vid,
    int vid0,
    int vid1)
{
    const std::vector<int>& faces = adjs_list[tar_vid];
    for (int i = 0; i < faces.size(); ++i) {
        int face_idx = faces[i];
        int cnt = 0;
        if (F(face_idx, 0) == vid0 || F(face_idx, 0) == vid1) {
            cnt++;
        }
        if (F(face_idx, 1) == vid0 || F(face_idx, 1) == vid1) {
            cnt++;
        }
        if (F(face_idx, 2) == vid0 || F(face_idx, 2) == vid1) {
            cnt++;
        }
        if (cnt == 2) {
            return true;
        }
    }
}

bool Prototype::isIntersect(
    Eigen::Vector2d l0p,
    Eigen::Vector2d l0q,
    Eigen::Vector2d l1p,
    Eigen::Vector2d l1q)
{
    auto orientation = [](Eigen::Vector2d b, Eigen::Vector2d e, Eigen::Vector2d p) -> bool {
        double ret = (e.y() - b.y()) * (p.x() - b.x()) - (e.x() - b.x()) * (p.y() - b.y());
        if (ret == 0) return 0;
        if (ret > 0) return 1;
        return 2;
    };

    int o1, o2, o3, o4;
    o1 = orientation(l0p, l0q, l1p);
    o2 = orientation(l0p, l0q, l1q);
    o3 = orientation(l1p, l1q, l0p);
    o4 = orientation(l1p, l1q, l0q);

    if (o1 != o2 && o3 != o4) return true;

    return false;
}

bool Prototype::needInvertNormal(Eigen::Vector2d mid, Eigen::Vector2d ori, std::vector<int> A)
{
    std::vector<int> potentialVs;
    for (int i = 0; i < A.size(); ++i) {
        if (isMarked(A[i])) {
            potentialVs.push_back(A[i]);
        }
    }

    std::vector<int> potentialEs;
    for (int i = 0; i < markedE.size(); ++i) {
        if (isExist(potentialVs, markedE[i][0]) || isExist(potentialVs, markedE[i][1])) {
            potentialEs.push_back(i);
        }
    }

    for (int i = 0; i < potentialEs.size(); ++i) {
        int vid0 = markedE[potentialEs[i]][0], vid1 = markedE[potentialEs[i]][1];
        Eigen::Vector2d v0(V(vid0, 0), V(vid0, 1)), v1(V(vid1, 0), V(vid1, 1));
        if (isIntersect(mid, ori, v0, v1)) {
            // std::cout << "here!!!!!!!!!!";
            return true;
        }
    }

    return false;
}

bool Prototype::onOffset(int vid)
{
    for (const int id : offset) {
        if (id == vid) return true;
    }
    return false;
}

bool Prototype::onOffset(int vid0, int vid1)
{
    if (vid0 > vid1) std::swap(vid0, vid1);
    for (const auto& edge : offset_edges) {
        if (edge[0] == vid0 && edge[1] == vid1) return true;
    }
    return false;
}

void Prototype::export_file(std::string path, bool need_obj, double max_padding_value)
{
    paraviewo::HDF5VTUWriter writer;
    Eigen::MatrixXd vertex_attributes(V.rows(), 1);
    // add inflation/offset attributes
    for (int i = 0; i < V.rows(); ++i) {
        if (isExist(markedV, i)) {
            vertex_attributes(i, 0) = 0; // original vertices
        } else if (isExist(offset, i)) {
            vertex_attributes(i, 0) = 1; // offset vertices
        } else {
            vertex_attributes(i, 0) = 2;
        }
    }

    std::vector<std::vector<int>> adj_list;
    // igl::adjacency_list(F, adj_list);
    getAdjList(adj_list);
    Eigen::MatrixXd face_attributes(F.rows(), 1);
    // add cell attributes, not sure
    for (int i = 0; i < F.rows(); ++i) {
        face_attributes(i, 0) = 0;
        bool connect_boundary = false;
        bool connect_origin = false;
        for (int j = 0; j < 3; ++j) {
            int idx = F(i, j);
            if (onOffset(idx)) {
                connect_boundary = true;
            }
            if (isMarked(idx)) {
                connect_origin = true;
            }
            if (connect_boundary && connect_origin) {
                face_attributes(i, 0) = 1;
                break;
            }
        }
    }
    writer.add_field("vertex_attributes", vertex_attributes);
    writer.add_cell_field("face_attributes", face_attributes);
    writer.write_mesh(path + "result.hdf", V, F);

    paraviewo::HDF5VTUWriter writer_edges;
    Eigen::MatrixXd edges_attributes(E.rows(), 1);
    for (int i = 0; i < E.rows(); ++i) {
        int vid0 = E(i, 0);
        int vid1 = E(i, 1);
        if (onOffset(vid0, vid1)) {
            edges_attributes(i, 0) = 0; // offset/inflation edges
        } else if (isMarked(vid0, vid1)) {
            edges_attributes(i, 0) = 2; // original edges
        } else {
            edges_attributes(i, 0) = 1;
        }
    }
    writer_edges.add_cell_field("edges_attributes", edges_attributes);
    writer_edges.write_mesh(path + "result_edges.hdf", V, E);

    if (P.rows() != 0) {
        paraviewo::HDF5VTUWriter writer_normal;
        Eigen::MatrixXd V_temp(offset.size() * 2, 2);
        Eigen::MatrixXi E_temp(offset.size(), 2);
        for (int i = 0; i < E_temp.rows(); ++i) {
            E_temp(i, 0) = i * 2;
            E_temp(i, 1) = i * 2 + 1;
            V_temp.row(i * 2) = V.row(offset[i]);
            V_temp.row(i * 2 + 1) = P.row(i);
        }
        writer_normal.write_mesh(path + "result_normals.hdf", V_temp, E_temp);
    }

    // this code block is for extract the simulation meshes
    // for padding
    paraviewo::HDF5VTUWriter writer_padding_meshes;
    std::vector<std::vector<int>> faces;
    for (int i = 0; i < F.rows(); ++i) {
        std::vector<int> indices;
        indices.push_back(F(i, 0));
        indices.push_back(F(i, 1));
        indices.push_back(F(i, 2));
        if (isMarked(F(i, 0)) || isMarked(F(i, 1)) || isMarked(F(i, 2))) continue;
        bool need_skip = false;
        for (int j = 0; j < 3; ++j) {
            if (V(indices[j], 0) > max_padding_value || V(indices[j], 0) < -max_padding_value) {
                need_skip = true;
                break;
            }
            if (V(indices[j], 1) > max_padding_value || V(indices[j], 1) < -max_padding_value) {
                need_skip = true;
                break;
            }
        }
        if (!need_skip) {
            faces.push_back(indices);
        }
    }
    Eigen::MatrixXi Faces_Padding(faces.size(), 3);
    for (int i = 0; i < Faces_Padding.rows(); ++i) {
        Faces_Padding(i, 0) = faces[i][0];
        Faces_Padding(i, 1) = faces[i][1];
        Faces_Padding(i, 2) = faces[i][2];
    }
    writer_padding_meshes.write_mesh(path + "result_padding.hdf", V, Faces_Padding);

    // for inflation
    paraviewo::HDF5VTUWriter writer_inflation_meshes;
    faces.clear();
    for (int i = 0; i < F.rows(); ++i) {
        std::vector<int> indices;
        indices.push_back(F(i, 0));
        indices.push_back(F(i, 1));
        indices.push_back(F(i, 2));
        if (isMarked(F(i, 0)) || isMarked(F(i, 1)) || isMarked(F(i, 2))) faces.push_back(indices);
    }
    Eigen::MatrixXi Faces_Inflation(faces.size(), 3);
    for (int i = 0; i < Faces_Inflation.rows(); ++i) {
        Faces_Inflation(i, 0) = faces[i][0];
        Faces_Inflation(i, 1) = faces[i][1];
        Faces_Inflation(i, 2) = faces[i][2];
    }
    writer_padding_meshes.write_mesh(path + "result_inflation.hdf", V, Faces_Inflation);

    if (need_obj) {
        // vertices
        Eigen::MatrixXd Vertices_Obj(V.rows(), 3);

        for (int i = 0; i < V.rows(); ++i) {
            double v0, v1;
            v0 = V(i, 0);
            v1 = V(i, 1);
            if (isnan(V(i, 0))) v0 = 0.0;
            if (isnan(V(i, 1))) v1 = 0.0;
            Vertices_Obj(i, 0) = v0;
            Vertices_Obj(i, 1) = v1;
            Vertices_Obj(i, 2) = 0.;
        }
        igl::writeOBJ(path + "result_padding.obj", Vertices_Obj, Faces_Padding);
        igl::writeOBJ(path + "result_inflation.obj", Vertices_Obj, Faces_Inflation);
    }
}

bool Prototype::isExist(const std::vector<int>& list, int idx)
{
    for (const int idx_list : list) {
        if (idx_list == idx) return true;
    }
    return false;
}

bool Prototype::isExist(const Eigen::MatrixXi& list, int idx)
{
    for (int i = 0; i < list.rows(); ++i) {
        if (list(i, 0) == idx) return true;
    }
    return false;
}

//
//       v3
//       /\  f1
//      /  \
//  v1 /_e0_\ v2
//     \    /
//      \  /
//       \/  f2
//       v4
//
// I'll use the toolkit later
int Prototype::split(int vid1, int vid2, SplitType type)
{ // GENERAL, OFFSET, INTERIOR, BOUNDARY
    if (type == GENERAL) {
        return split_general(vid1, vid2);
    } else if (type == OFFSET) {
        return split_offset(vid1, vid2);
    } else if (type == INTERIOR) {
        return split_interior(vid1, vid2);
    } else if (type == BOUNDARY) {
        return split_boundary(vid1, vid2);
    }

    return -1;
}

int Prototype::split_general(int vid1, int vid2)
{
    if (vid1 > vid2) std::swap(vid1, vid2);
    Eigen::MatrixXi EV, FE, EF;
    igl::edge_topology(V, F, EV, FE, EF);
    int edge_id = -1, vid3 = -1, vid4 = -1, vidsplit = -1, fid1 = -1, fid2 = -1;
    vidsplit = V.rows();

    // find edge_id
    for (int i = 0; i < EV.rows(); ++i) {
        int ev0 = EV(i, 0), ev1 = EV(i, 1);
        if (ev0 > ev1) std::swap(ev0, ev1);
        if (ev0 == vid1 && ev1 == vid2) {
            edge_id = i;
            break;
        }
    }
    assert(edge_id >= 0);
    fid1 = EF(edge_id, 0);
    fid2 = EF(edge_id, 1);
    int idx_1;
    // get vid3 and vid4, then adjust vid1 and vid2
    for (int i = 0; i < 3; ++i) {
        if (F(fid1, i) != vid1 && F(fid1, i) != vid2) {
            vid3 = F(fid1, i);
            idx_1 = (i + 1) % 3;
        }
        if (F(fid2, i) != vid1 && F(fid2, i) != vid2) {
            vid4 = F(fid2, i);
        }
    }
    assert(vid3 >= 0);
    assert(vid4 >= 0);
    if (F(fid1, idx_1) != vid1) {
        std::swap(vid1, vid2);
    }

    // new split point
    Eigen::MatrixXd newpoint(1, 2), newV(V.rows() + 1, V.cols());
    newpoint << (V(vid1, 0) + V(vid2, 0)) * 0.5, (V(vid1, 1) + V(vid2, 1)) * 0.5;
    newV << V, newpoint;
    V = newV;
    // four new face, remember replace original ones
    Eigen::MatrixXi newface1(1, 3), newface2(1, 3), newface3(1, 3), newface4(1, 3);
    Eigen::MatrixXi newfaces(F.rows() + 2, F.cols());
    // top-left
    newface1 << vid1, vidsplit, vid3;
    // top-right
    newface2 << vid2, vid3, vidsplit;
    // bottom-left
    newface3 << vid1, vid4, vidsplit;
    // bottom-right
    newface4 << vid4, vid2, vidsplit;
    newfaces << F, newface2, newface4;
    newfaces.row(fid1) = newface1;
    newfaces.row(fid2) = newface3;
    F = newfaces;
    // update E
    igl::edges(F, E);

    return vidsplit;
}

int Prototype::split_offset(int vid1, int vid2)
{
    int vid_split = split_general(vid1, vid2);

    offset.push_back(vid_split);

    std::vector<int> e0, e1;
    int evid0, evid1;

    evid0 = vid1;
    evid1 = vid_split;
    if (evid0 > evid1) std::swap(evid0, evid1);
    e0.push_back(evid0);
    e0.push_back(evid1);
    offset_edges.push_back(e0);

    evid0 = vid2;
    evid1 = vid_split;
    if (evid0 > evid1) std::swap(evid0, evid1);
    e1.push_back(evid0);
    e1.push_back(evid1);
    offset_edges.push_back(e1);

    evid0 = vid1;
    evid1 = vid2;
    if (evid0 > evid1) std::swap(evid0, evid1);
    for (int i = 0; i < offset_edges.size(); ++i) {
        const std::vector<int>& edge = offset_edges[i];
        if (edge[0] == evid0 && edge[1] == evid1) {
            offset_edges.erase(offset_edges.begin() + i);
            break;
        }
    }

    return vid_split;
}

int Prototype::split_interior(int vid1, int vid2)
{
    int vid_split = split_general(vid1, vid2);

    std::vector<std::vector<int>> adjs_list;
    getAdjList(adjs_list);

    if (adjs_list[vid_split].size() != 4) {
        std::cout << "int split_interior() adjs_list[vid_split].size()!" << std::endl;
        exit(1);
    }
    int record_offset_vid = -1;
    std::vector<int> near_offset_vids;
    for (int i = 0; i < adjs_list[vid_split].size(); ++i) {
        int idx = adjs_list[vid_split][i];
        if (onOffset(idx)) {
            if (idx == vid1) {
                record_offset_vid = vid1;
            } else if (idx == vid2) {
                record_offset_vid = vid2;
            } else {
                near_offset_vids.push_back(idx);
            }
        }
    }

    if (record_offset_vid == -1) {
        std::cout << "record_offset_vid == -1 !!" << std::endl;
        exit(1);
    }

    if (near_offset_vids.size() > 2) {
        std::cout << near_offset_vids.size();
        std::cout << "near_offset_vids.size() goes wrong !!" << std::endl;
        exit(1);
    }

    if (near_offset_vids.size() == 1) {
        // delete one offset edge
        int vid1_, vid2_;
        vid1_ = record_offset_vid;
        vid2_ = near_offset_vids[0];
        if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        for (int i = 0; i < offset_edges.size(); ++i) {
            if (offset_edges[i][0] == vid1_ && offset_edges[i][1] == vid2_) {
                offset_edges.erase(offset_edges.begin() + i);
                break;
            }
        }
        // add two new offset edges
        std::vector<int> e0, e1;
        // e0
        vid1_ = record_offset_vid;
        vid2_ = vid_split;
        if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        e0.push_back(vid1_);
        e0.push_back(vid2_);
        offset_edges.push_back(e0);
        // e1
        vid1_ = vid_split;
        vid2_ = near_offset_vids[0];
        if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        e1.push_back(vid1_);
        e1.push_back(vid2_);
        offset_edges.push_back(e1);
        offset.push_back(vid_split);
    } else if (near_offset_vids.size() == 2) {
        int vid1_, vid2_, evid0, evid1;
        vid1_ = near_offset_vids[0];
        vid2_ = near_offset_vids[1];

        evid0 = vid1_;
        evid1 = record_offset_vid;
        if (evid0 > evid1) std::swap(evid0, evid1);
        for (int i = 0; i < offset_edges.size(); ++i) {
            if (offset_edges[i][0] == evid0 && offset_edges[i][1] == evid1) {
                int new_evid0 = vid_split;
                int new_evid1 = vid1_;
                if (new_evid0 > new_evid1) std::swap(new_evid0, new_evid1);
                offset_edges[i][0] = new_evid0;
                offset_edges[i][1] = new_evid1;
                break;
            }
        }

        evid0 = vid2_;
        evid1 = record_offset_vid;
        if (evid0 > evid1) std::swap(evid0, evid1);
        for (int i = 0; i < offset_edges.size(); ++i) {
            if (offset_edges[i][0] == evid0 && offset_edges[i][1] == evid1) {
                int new_evid0 = vid_split;
                int new_evid1 = vid2_;
                if (new_evid0 > new_evid1) std::swap(new_evid0, new_evid1);
                offset_edges[i][0] = new_evid0;
                offset_edges[i][1] = new_evid1;
                break;
            }
        }

        for (int i = 0; i < offset.size(); ++i) {
            if (offset[i] == record_offset_vid) {
                offset[i] = vid_split;
                break;
            }
        }
        //// delete one offset edge
        // int vid1_, vid2_;
        // vid1_ = record_offset_vid;
        // vid2_ = near_offset_vids[0];
        // if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        // for (int i = 0; i < offset_edges.size(); ++i) {
        //     if (offset_edges[i][0] == vid1_ && offset_edges[i][1] == vid2_) {
        //         offset_edges.erase(offset_edges.begin() + i);
        //         break;
        //     }
        // }
        //// add three new offset edges
        // std::vector<int> e0, e1, e2;
        //// e0
        // vid1_ = record_offset_vid;
        // vid2_ = near_offset_vids[1];
        // if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        // e0.push_back(vid1_);
        // e0.push_back(vid2_);
        // offset_edges.push_back(e0);
        ////e1
        // vid1_ = record_offset_vid;
        // vid2_ = vid_split;
        // if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        // e1.push_back(vid1_);
        // e1.push_back(vid2_);
        // offset_edges.push_back(e1);
        ////e2
        // vid1_ = vid_split;
        // vid2_ = near_offset_vids[0];
        // if (vid1_ > vid2_) std::swap(vid1_, vid2_);
        // e2.push_back(vid1_);
        // e2.push_back(vid2_);
        // offset_edges.push_back(e2);
        // offset.push_back(vid_split);
    }

    return vid_split;
}

int Prototype::split_boundary(int vid0, int vid1)
{
    int vidsplit = V.rows();
    if (vid0 > vid1) std::swap(vid0, vid1);

    Eigen::MatrixXi EV, FE, EF;
    igl::edge_topology(V, F, EV, FE, EF);

    int eid = -1;
    for (int i = 0; i < EV.rows(); ++i) {
        int evid0 = EV(i, 0);
        int evid1 = EV(i, 1);
        if (evid0 > evid1) std::swap(evid0, evid1);
        if (evid0 == vid0 && evid1 == vid1) {
            eid = i;
            break;
        }
    }
    assert(eid >= 0);

    int fid = -1;
    fid = EF(eid, 0) > EF(eid, 1) ? EF(eid, 0) : EF(eid, 1);
    assert(fid >= 0);

    int vid2 = -1;
    int adjust_idx = -1;
    for (int i = 0; i < 3; ++i) {
        if (F(fid, i) != vid0 && F(fid, i) != vid1) {
            adjust_idx = i;
            vid2 = F(fid, i);
            break;
        }
    }
    assert(vid2 >= 0);

    if (adjust_idx == 0) {
        vid0 = F(fid, 1);
        vid1 = F(fid, 2);
    } else if (adjust_idx == 1) {
        vid0 = F(fid, 2);
        vid1 = F(fid, 0);
    } else {
        vid0 = F(fid, 0);
        vid1 = F(fid, 1);
    }

    Eigen::MatrixXi newF(F.rows() + 1, F.cols());
    newF << F, vidsplit, vid2, vid0;
    newF.row(fid) << vid2, vidsplit, vid1;
    F = newF;

    Eigen::MatrixXd newV(V.rows() + 1, V.cols());
    newV << V, (V.row(vid0) + V.row(vid1)) * 0.5;
    V = newV;

    igl::edges(F, E);
    updateBoundary();

    return vidsplit;
}

//
//                              vid2
//        /\vid2                 |
//       /  \       split   fid0 |  fid1
//      /    \       -->      vidsplit
// vid0/_ _ _ \vid1            /   \
//                            /fid2 \
//                         vid0     vid1
int Prototype::splitface(int fid)
{
    int vidsplit = V.rows(), vid0 = F(fid, 0), vid1 = F(fid, 1), vid2 = F(fid, 2);
    // add new vertex
    Eigen::RowVectorXd splitV = (V.row(vid0) + V.row(vid1) + V.row(vid2)) / 3;
    Eigen::MatrixXd newV;
    newV.resize(V.rows() + 1, V.cols());
    newV << V, splitV;
    V = newV;

    // add new face
    Eigen::RowVectorXi f0(1, 3), f1(1, 3), f2(1, 3);
    f0 << vidsplit, vid2, vid0;
    f1 << vidsplit, vid1, vid2;
    f2 << vidsplit, vid0, vid1;
    F.row(fid) = f0;
    Eigen::MatrixXi newF;
    newF.resize(F.rows() + 2, F.cols());
    newF << F, f1, f2;
    F = newF;

    return vidsplit;
}

void Prototype::flip(int& vid1, int& vid2)
{
    int vid3, vid4, fid1, fid2;
    get_target_edge_topology(vid1, vid2, vid3, vid4, fid1, fid2);
    Eigen::RowVectorXi newf1(1, 3), newf2(1, 3);
    newf1 << vid1, vid4, vid3;
    newf2 << vid2, vid3, vid4;
    F.row(fid1) = newf1;
    F.row(fid2) = newf2;
    std::swap(vid1, vid4);
    std::swap(vid2, vid3);
    std::swap(vid3, vid4);
    igl::edges(F, E);
}

void Prototype::flip(int& vid1, int& vid2, int& vid3, int& vid4, int& fid1, int& fid2)
{
    Eigen::RowVectorXi newf1(1, 3), newf2(1, 3);
    newf1 << vid1, vid4, vid3;
    newf2 << vid2, vid3, vid4;
    F.row(fid1) = newf1;
    F.row(fid2) = newf2;
    std::swap(vid1, vid4);
    std::swap(vid2, vid3);
    std::swap(vid3, vid4);
    igl::edges(F, E);
}

int Prototype::valence(int vid, const std::vector<std::vector<int>>& adj)
{
    return adj[vid].size();
}

int Prototype::target_valence(int vid)
{
    if (onBoundary(vid)) {
        return 4;
    }
    return 6;
}

double Prototype::get_mean_ratio_vaule(int vid0, int vid1, int vid2, int vid3)
{
    double ret = 0;
    Eigen::Vector3d v0(V(vid0, 0), V(vid0, 1), 0);
    Eigen::Vector3d v1(V(vid1, 0), V(vid1, 1), 0);
    Eigen::Vector3d v2(V(vid2, 0), V(vid2, 1), 0);
    Eigen::Vector3d v3(V(vid3, 0), V(vid3, 1), 0);

    // v0 v1 v2 -- l0 l1 l2
    // v0 v1 v3 -- l0 l3 l4
    Eigen::Vector3d l0, l1, l2, l3, l4;
    l0 = v0 - v1;
    l1 = v0 - v2;
    l2 = v1 - v2;
    l3 = v0 - v3;
    l4 = v3 - v2;

    double len0, len1, len2, len3, len4;
    len0 = l0.norm();
    len1 = l1.norm();
    len2 = l2.norm();
    len3 = l3.norm();
    len4 = l4.norm();

    ret += 1.73 * (std::fabs((v1 - v0).cross(v2 - v0).z())) /
           (len0 * len0 + len1 * len1 + len2 * len2);
    ret += 1.73 * (std::fabs((v1 - v0).cross(v3 - v0).z())) /
           (len0 * len0 + len3 * len3 + len4 * len4);

    return ret;
}

// vid0 collapses to vid1
bool Prototype::collapse(int vid0, int vid1, double high)
{
    if (vid0 == vid1) return false;
    if (onBoundary(vid0, vid1)) return false;
    // check if this operation is valid, it seems in this delauney triangulation,there is no special
    // case
    int vid2, vid3, fid0, fid1;
    int record = vid0;
    get_target_edge_topology(vid0, vid1, vid2, vid3, fid0, fid1);
    Eigen::RowVectorXd tempVrow = V.row(vid1);
    Eigen::MatrixXi tempF(F);

    std::vector<std::vector<int>> adj_list;
    // igl::adjacency_list(F, adj_list);
    getAdjList(adj_list);
    int cnt = 0;
    for (int i = 0; i < adj_list[vid0].size(); ++i) {
        for (int j = 0; j < adj_list[vid1].size(); ++j) {
            if (adj_list[vid0][i] == adj_list[vid1][j]) {
                ++cnt;
                break;
            }
        }
    }
    if (cnt > 2) return false;

    // check is the result is desired
    Eigen::RowVectorXd midV = (V.row(vid0) + V.row(vid1)) * 0.5;
    for (int i = 0; i < adj_list[vid0].size(); ++i) {
        double dis = (V.row(adj_list[vid0][i]) - midV).norm();
        // std::cout << dis << std::endl;
        if (dis > high) {
            return false;
        }
    }

    V.row(vid1) = midV;

    for (int i = 0; i < F.rows(); ++i) {
        if (F(i, 0) == vid0) {
            F(i, 0) = vid1;
        } else if (F(i, 1) == vid0) {
            F(i, 1) = vid1;
        } else if (F(i, 2) == vid0) {
            F(i, 2) = vid1;
        }
    }

    // update F's size
    Eigen::MatrixXi newF(F.rows() - 2, 3);
    int offset = 0;
    for (int i = 0; i < F.rows(); ++i) {
        if (i == fid0 || i == fid1) {
            offset++;
            continue;
        }
        newF.row(i - offset) = F.row(i);
    }
    F = newF;
    igl::edges(F, E);

    // bisection search
    for (int i = 0; i < 5; ++i) {
        if (!isInvert()) {
            break;
        }
        V.row(vid1) = (V.row(vid1) + tempVrow) * 0.5;
    }

    if (isInvert()) {
        F = tempF;
        V.row(vid1) = tempVrow;
        igl::edges(F, E);
        return false;
    }
    return true;
}

bool Prototype::isInvert()
{
    Eigen::MatrixXd A;
    igl::doublearea(V, F, A);
    for (int i = 0; i < A.rows(); ++i) {
        if (A(i, 0) < 0) return true;
    }
    return false;
}

void Prototype::get_target_edge_topology(
    int& vid1_, // input&output
    int& vid2_, // input&output
    int& vid3_, // output
    int& vid4_, // output
    int& fid1_, // output
    int& fid2_) // output
{
    int vid1 = vid1_;
    int vid2 = vid2_;
    bool asc_order = false;
    if (vid1 > vid2) asc_order = true;
    Eigen::MatrixXi EV, FE, EF;
    igl::edge_topology(V, F, EV, FE, EF);
    int edge_id = -1, vid3 = -1, vid4 = -1, fid1 = -1, fid2 = -1;
    // find edge_id
    for (int i = 0; i < EV.rows(); ++i) {
        int ev0 = EV(i, 0), ev1 = EV(i, 1);
        if (ev0 <= ev1 && asc_order) std::swap(ev0, ev1);
        if (ev0 == vid1 && ev1 == vid2) {
            edge_id = i;
            break;
        }
    }

    assert(edge_id >= 0);
    fid1 = EF(edge_id, 0);
    fid2 = EF(edge_id, 1);
    if (fid1 < 0 || fid2 < 0) {
        std::cout << "Inflation.cpp - void get_target_edge_topology()" << std::endl;
        std::cout << fid1 << " " << fid2 << std::endl;
        updateBoundary();
        std::cout << vid1 << " " << isMarked(vid1) << " " << vid2 << " " << isMarked(vid2);
        markedV.push_back(vid1);
        markedV.push_back(vid2);
        export_file("D:\\");
        exit(1);
    }
    int idx_1;
    // get vid3 and vid4, then adjust vid1 and vid2
    for (int i = 0; i < 3; ++i) {
        if (F(fid1, i) != vid1 && F(fid1, i) != vid2) {
            vid3 = F(fid1, i);
            idx_1 = (i + 1) % 3;
        }
        if (F(fid2, i) != vid1 && F(fid2, i) != vid2) {
            vid4 = F(fid2, i);
        }
    }
    assert(vid3 >= 0);
    assert(vid4 >= 0);
    if (F(fid1, idx_1) != vid1) {
        std::swap(vid3, vid4);
    }

    vid1_ = vid1;
    vid2_ = vid2;
    vid3_ = vid3;
    vid4_ = vid4;
    fid1_ = fid1;
    fid2_ = fid2;
}

void Prototype::remesh(
    double inflation_rate,
    int iteration_times,
    double target_edge_length,
    FLIP_METHOD method)
{
    if (target_edge_length == -1) {
        target_edge_length = igl::avg_edge_length(V, F);
    }
    if (target_edge_length < 0) return;

    double distance = inflation_rate * target_edge_length;

    std::cout << "remeshing is processing..." << std::endl;
    updateBoundary();
    double low = 0.8 * target_edge_length;
    double high = 4.0 / 3.0 * target_edge_length;
    for (int i = 0; i < iteration_times; ++i) {
        std::cout << "remeshing_iteration:" << i + 1 << std::endl;
        remesh_split(high);
        remesh_collapse(low, high);
        remesh_flip(MEANRATIO);
        remesh_relocate(distance);
    }
    // remesh_project_to_input();
    std::cout << "remeshing is done!" << std::endl;
}

// split all edges at their midpoint that are longer than 0.75*len
// NOTE: in this project I ignore the offset edges
void Prototype::remesh_split(double high)
{
    // only take care of the case of edges having two offset vertices
    igl::edges(F, E);
    Eigen::MatrixXd L;
    igl::edge_lengths(V, E, L);
    std::vector<std::pair<int, int>> split_edge_list;
    for (int i = 0; i < L.rows(); ++i) {
        int vid0 = E(i, 0);
        int vid1 = E(i, 1);

        if (isMarked(vid0) || isMarked(vid1)) continue;
        if (isMarked(vid0, vid1)) continue;

        if (L(i, 0) > high) {
            split_edge_list.push_back(std::pair<int, int>(vid0, vid1));
        }
    }

    int split_num = split_edge_list.size();
    while (split_edge_list.size()) {
        std::pair<int, int> split_edge = split_edge_list.back();
        split_edge_list.pop_back();
        int vid0, vid1;
        vid0 = split_edge.first;
        vid1 = split_edge.second;

        int vid_mid = -1;
        if (onBoundary(vid0) && onBoundary(vid1))
            vid_mid = split(vid0, vid1, BOUNDARY);
        else if (onOffset(vid0, vid1))
            vid_mid = split(vid0, vid1, OFFSET);
        else if ((onOffset(vid1) && isMarked(vid0)) || (onOffset(vid0) && isMarked(vid1)))
            vid_mid = split(vid0, vid1, INTERIOR);
        else
            vid_mid = split(vid0, vid1, GENERAL);

        if ((V.row(vid0) - V.row(vid_mid)).norm() > high) {
            split_edge_list.push_back(std::pair<int, int>(vid0, vid_mid));
        }
        if ((V.row(vid1) - V.row(vid_mid)).norm() > high) {
            split_edge_list.push_back(std::pair<int, int>(vid1, vid_mid));
        }
    }
    std::cout << "split_num:" << split_num << std::endl;
}
// collapse all edges shorter than 0.8*len
//
// note for myself:
// only a topology following these two rules will generate valid topology after collapse operation
// 1. If both p and q are offset vertices, then the edge p-q has to be a offset edge.
// 2. For all vertices r incident to both p and q there has to be a triangle p-q-r. In other words,
// the intersection of the one-rings of p and q consists of vertices opposite of the edge p-q.
//
// my solution:
// before doing collapse operation, check if the topology is valid. if it is valid, then directly
// call collapse function
//
void Prototype::remesh_collapse(double low, double high)
{
    int collapse_num = 0;
    // only take care of the case of edges having two offset vertices
    igl::edges(F, E);
    Eigen::MatrixXd L;
    igl::edge_lengths(V, E, L);
    std::vector<std::pair<int, int>> collapse_edge_list;
    for (int i = 0; i < L.rows(); ++i) {
        int vid0 = E(i, 0);
        int vid1 = E(i, 1);
        // skip plane offset and original vertices
        if (onBoundary(vid0) || onBoundary(vid1) || isMarked(vid0) || isMarked(vid1)) continue;

        if (onOffset(vid0, vid1) || onOffset(vid0) || onOffset(vid1)) continue;

        if (L(i, 0) < low) {
            if (vid0 > vid1) std::swap(vid0, vid1);
            collapse_edge_list.push_back(std::pair<int, int>(vid0, vid1));
        }
    }

    std::vector<int> deletedV; // record the deleted vertices
    while (collapse_edge_list.size()) {
        std::pair<int, int> collapse_edge = collapse_edge_list.back();
        collapse_edge_list.pop_back();
        int vid0, vid1;
        vid0 = collapse_edge.first;
        vid1 = collapse_edge.second;
        if (onBoundary(vid0) || onBoundary(vid1)) continue;

        // collapse
        // std::cout << deletedV.size() << std::endl;
        // if (vid0 == 1469 && vid1 == 1895) {
        //    updateBoundary();
        //    for (int j = 0; j < boundary.rows(); j++) {
        //        markedV.push_back(boundary(j, 0));
        //    }
        //    export_file("D:\\");
        //    exit(1);
        //}
        if (collapse(vid0, vid1, high)) {
            // std::cout << vid0 << " " << vid1 << std::endl;
            updateBoundary();
            collapse_num++;
            deletedV.push_back(vid0);
            for (std::pair<int, int>& e : collapse_edge_list) {
                if (e.first == vid0) e.first = vid1;
                if (e.second == vid0) e.second = vid1;
            }
            for (int i = collapse_edge_list.size() - 1; i >= 0; --i) {
                if (collapse_edge_list[i].first == collapse_edge_list[i].second) {
                    collapse_edge_list.erase(collapse_edge_list.begin() + i);
                }
            }

            // this block is for offset/offset vertices' collapse
            // if vid0-vid1 is on offset/offset, then I need update the offset and offset_edges
            if (onOffset(vid0, vid1)) {
                // vid0 will disappear, therefore update offset and boudnary_edges' vid0
                for (int i = 0; i < offset.size(); ++i) {
                    if (i == vid0) {
                        offset.erase(i + offset.begin());
                        break;
                    }
                }
                for (int i = 0; i < offset_edges.size(); ++i) {
                    if (offset_edges[i][0] == vid0) {
                        offset_edges[i][0] = vid1;
                    } else if (offset_edges[i][1] == vid0) {
                        offset_edges[i][1] = vid1;
                    }
                }
                for (int i = 0; i < offset_edges.size(); ++i) {
                    if (offset_edges[i][0] == offset_edges[i][1]) {
                        offset_edges.erase(i + offset_edges.begin());
                        break;
                    }
                }
            }
        }
    }

    igl::edges(F, E);

    std::cout << "collapse_num:" << collapse_num << std::endl;
}

// flip edges in order to minimize the deviation from valence 6(or 4 on boundaries)
//
// note for myself:
// from the book Polygon Mesh Processing, it is said that this process actually is tentatively
// fliping each edge and check whether the valence of target vertex becomes more closer to 4 or 6.
// If not, then flip back.
//
void Prototype::remesh_flip(FLIP_METHOD method)
{
    int flip_num = 0;
    updateBoundary();
    Eigen::MatrixXi EF, FE;
    // igl::edge_topology(V, F, E, EF, FE);
    igl::edges(F, E);

    for (int i = 0; i < E.rows(); ++i) {
        int vid1 = E(i, 0);
        int vid2 = E(i, 1);
        bool isoffset = false;

        if (onBoundary(vid1) && onBoundary(vid2))
            continue;
        else if (isMarked(vid1, vid2))
            continue;
        else if (onOffset(vid1, vid2))
            continue;
        else if (onOffset(vid1) && isMarked(vid2))
            isoffset = true;
        else if (onOffset(vid2) && isMarked(vid1))
            isoffset = true;

        int vid3, vid4, fid1, fid2;
        std::vector<std::vector<int>> adj;
        // igl::adjacency_list(F, adj);
        getAdjList(adj);
        get_target_edge_topology(vid1, vid2, vid3, vid4, fid1, fid2);

        if (onOffset(vid3) && onOffset(vid4)) continue;
        if (isMarked(vid3) && isMarked(vid4)) continue;

        if (isoffset) {
            double len_pre = (V.row(vid1) - V.row(vid2)).norm();
            double len_post = (V.row(vid3) - V.row(vid4)).norm();
            if (adj[vid1].size() > 3 && adj[vid1].size() > 3 && len_pre > len_post) {
                flip(vid1, vid2, vid3, vid4, fid1, fid2);
                if (isInvert() || !igl::is_edge_manifold(F))
                    flip(vid1, vid2, vid3, vid4, fid1, fid2);
                else
                    flip_num++;
                assert(!isInvert());
            }
        } else {
            if (method == MEANRATIO) {
                double mean_ratio_value_pre = get_mean_ratio_vaule(vid1, vid2, vid3, vid4);
                double mean_ratio_value_post = get_mean_ratio_vaule(vid4, vid3, vid1, vid2);

                if (mean_ratio_value_post > mean_ratio_value_pre) {
                    flip(vid1, vid2, vid3, vid4, fid1, fid2);
                    // igl::adjacency_list(F, adj);
                    if (mean_ratio_value_post < mean_ratio_value_pre || isInvert() ||
                        (onOffset(vid1) && onOffset(vid2)) || !igl::is_edge_manifold(F)) {
                        flip(vid1, vid2, vid3, vid4, fid1, fid2);
                    } else {
                        flip_num++;
                    }
                }

            } else if (method == EQUALIZED) {
                int deviation_pre = abs(valence(vid1, adj) - target_valence(vid1)) +
                                    abs(valence(vid2, adj) - target_valence(vid2)) +
                                    abs(valence(vid3, adj) - target_valence(vid3)) +
                                    abs(valence(vid4, adj) - target_valence(vid4));
                flip(vid1, vid2, vid3, vid4, fid1, fid2);
                // igl::adjacency_list(F, adj);
                getAdjList(adj);

                int deviation_post = abs(valence(vid1, adj) - target_valence(vid1)) +
                                     abs(valence(vid2, adj) - target_valence(vid2)) +
                                     abs(valence(vid3, adj) - target_valence(vid3)) +
                                     abs(valence(vid4, adj) - target_valence(vid4));
                if (deviation_pre < deviation_post || isInvert() ||
                    (onOffset(vid1) && onOffset(vid2)) || !igl::is_edge_manifold(F))
                    flip(vid1, vid2, vid3, vid4, fid1, fid2);
                else
                    flip_num++;
            }
        }
    }

    std::cout << "flip_num:" << flip_num << std::endl;
    // for (int i = 0; i < E.rows(); ++i) {
    //     int vid1 = E(i, 0);
    //     int vid2 = E(i, 1);
    //     bool isoffset = false;

    //    if (isExist(B, vid1) && isExist(B, vid2))
    //        continue;
    //    else if (isMarked(vid1, vid2))
    //        continue;
    //    else if (onOffset(vid1, vid2))
    //        continue;
    //    else if (onOffset(vid1) && isMarked(vid2))
    //        continue;
    //    //isoffset = true;
    //    else if (onOffset(vid2) && isMarked(vid1))
    //        continue;
    //    //isoffset = true;

    //    int vid3, vid4, fid1, fid2;
    //    double len_pre, len_post, mean_ratio_value_pre, mean_ratio_value_post;
    //    std::vector<std::vector<int>> adj;
    //    igl::adjacency_list(F, adj);
    //    get_target_edge_topology(vid1, vid2, vid3, vid4, fid1, fid2);

    //    len_pre = (V.row(vid1) - V.row(vid2)).norm();
    //    len_post = (V.row(vid3) - V.row(vid4)).norm();

    //    if (adj[vid1].size() <= 3 || adj[vid2].size() <= 3)
    //        continue;

    //    if (isoffset && (len_post >= len_pre) || (onOffset(vid3) && onOffset(vid4)))
    //        continue;
    //
    //    //mean_ratio_value_pre = get_mean_ratio_vaule(vid1, vid2, vid3, vid4);
    //    int deviation_pre = abs(valence(vid1, adj) - target_valence(vid1, B)) +
    //                    abs(valence(vid2, adj) - target_valence(vid2, B)) +
    //                    abs(valence(vid3, adj) - target_valence(vid3, B)) +
    //                    abs(valence(vid4, adj) - target_valence(vid4, B));
    //    flip(vid1, vid2, vid3, vid4, fid1, fid2);

    //    //mean_ratio_value_post = get_mean_ratio_vaule(vid1, vid2, vid3, vid4);
    //    int deviation_post = abs(valence(vid1, adj) - target_valence(vid1, B)) +
    //                    abs(valence(vid2, adj) - target_valence(vid2, B)) +
    //                    abs(valence(vid3, adj) - target_valence(vid3, B)) +
    //                    abs(valence(vid4, adj) - target_valence(vid4, B));
    //
    //    if (isInvert() || deviation_pre < deviation_post)
    //    //if (isInvert() || mean_ratio_value_post < mean_ratio_value_pre)
    //        flip(vid1, vid2, vid3, vid4, fid1, fid2);
    //    else
    //        flip_num++;
    //}
}

// relocate vertices on the surface by tangential smoothing, for now, just use the average position
// of neighbours'
void Prototype::remesh_relocate(double distance, int iteration_time)
{
    std::vector<std::vector<int>> adj_list;
    // igl::adjacency_list(F, adj_list);
    getAdjList(adj_list);
    updateBoundary();

    for (int time = 0; time < iteration_time; ++time) {
        for (int i = 0; i < V.rows(); ++i) {
            const std::vector<int>& adjs = adj_list[i];
            if (isMarked(i) || onBoundary(i) || onOffset(i)) continue;

            Eigen::RowVectorXd tempRowV = V.row(i);
            V.row(i) << 0, 0;

            for (int j = 0; j < adjs.size(); ++j) {
                V.row(i) += V.row(adjs[j]);
            }
            V.row(i) /= adjs.size() * 1.0;

            for (int j = 0; j < 5; ++j) {
                if (!isInvert()) {
                    break;
                }
                V.row(i) = (V.row(i) + tempRowV) * 0.5;
            }
            if (isInvert()) {
                V.row(i) = tempRowV;
            }
        }
    }

    std::vector<std::vector<int>> neighbours_list(V.rows(), std::vector<int>());
    for (int i = 0; i < offset_edges.size(); ++i) {
        int idx0, idx1;
        idx0 = offset_edges[i][0];
        idx1 = offset_edges[i][1];
        neighbours_list[idx0].push_back(idx1);
        neighbours_list[idx1].push_back(idx0);
    }

    P.resize(offset.size(), 2);
    // this part is for the offset generation
    Eigen::MatrixXd tempV = V;
    for (int i = 0; i < offset.size(); ++i) {
        int idx = offset[i];

        if (idx == 378) {
            int stop = 1;
        }

        const std::vector<int>& neighbours = neighbours_list[idx];
        if (neighbours.size() == 2) {
        } else {
            std::cout << "something wrong with offset_edges!" << std::endl;
            std::cout << "neighbours size:" << neighbours.size() << std::endl;
            exit(1);
        }
        Eigen::RowVectorXd mid(1, 2), proj(1, 2), n(1, 2);
        mid = (V.row(neighbours[0]) + V.row(neighbours[1])) * 0.5;
        Eigen::RowVectorXd safe_pos = V.row(idx);
        Eigen::RowVectorXd record_V = V.row(idx);
        V.row(idx) = mid;
        Eigen::RowVectorXd goal = mid;

        for (int j = 0; j < 8; ++j) {
            // bisection search
            if (isInvert()) {
                V.row(idx) = (V.row(idx) + safe_pos) * 0.5;
            } else {
                if (j == 0) break;
                record_V = V.row(idx);
                V.row(idx) = (V.row(idx) + goal) * 0.5;
            }
        }
        if (isInvert()) {
            V.row(idx) = record_V;
        }

        Eigen::Vector2d proj_ = getClosestPointOnInput(idx, V);
        proj(0, 0) = proj_.x();
        proj(0, 1) = proj_.y();
        P(i, 0) = proj.x();
        P(i, 1) = proj.y();
        // V.row(idx) = tempRowV;

        safe_pos = V.row(idx);
        n = (V.row(idx) - proj).normalized();

        // needInvertNormal(mid, tempRowV, adj_list[idx]);
        goal = V.row(idx) = proj + n * distance;

        for (int j = 0; j < 8; ++j) {
            // bisection search
            if (isInvert()) {
                V.row(idx) = (V.row(idx) + safe_pos) * 0.5;
            } else {
                if (j == 0) break;
                record_V = V.row(idx);
                V.row(idx) = (V.row(idx) + goal) * 0.5;
            }
        }
        if (isInvert()) {
            // if the otherside can not find the offset either, then end finding
            V.row(idx) = record_V;
        }

        // found the valid average, and then recompute the offset
        // if the position is updated, then recompute the offset's position
        /********************this block is used to resample the offset*************************/
#if 0
                if (neighbours.size() == 2) {
            // do recompute and check whether the result is valid
            // firstly, restore the originl vertex position
            Eigen::RowVectorXd tempRowV = tempV.row(idx);
            // second, compute the averge position of the neighbours' position and bisection search
            V.row(idx) = (tempV.row(neighbours[0]) + tempV.row(neighbours[1])) * 0.5;
            for (int j = 0; j < 5; ++j) {
                if (!isInvert()) break;
                // bisection search
                V.row(idx) = (tempV.row(idx) + tempRowV) * 0.5;
            }
            if (isInvert()) {
                V.row(idx) = tempRowV;
            }
            if ((tempRowV - V.row(idx)).norm() != 0.0) {
                tempV.row(idx) = V.row(idx);
                Eigen::Vector2d proj = getClosestPointOnInput(idx, tempV);
                tempV.row(idx) = tempRowV;
                Eigen::Vector2d nv0(tempV(neighbours[0], 0), tempV(neighbours[0], 1)),
                    nv1(tempV(neighbours[1], 0), tempV(neighbours[1], 1)),
                    newv(V(idx, 0), V(idx, 1)), oldv(tempRowV(0, 0), tempRowV(0, 1));
                if (recomputeOffset(nv0, nv1, newv, oldv, proj)) {
                    tempRowV = V.row(idx);
                    V(idx, 0) = newv.x();
                    V(idx, 1) = newv.y();
                    Eigen::RowVectorXd lasttempRowV = tempV.row(idx);
                    for (int j = 0; j < 5; ++j) {
                        // bisection search
                        if (isInvert()) {
                            V.row(idx) = (V.row(idx) + tempRowV) * 0.5;
                            lasttempRowV = V.row(idx);
                        } else {
                            V.row(idx) = (V.row(idx) + lasttempRowV) * 0.5;
                            lasttempRowV = V.row(idx);
                        }
                    }
                    if (isInvert()) {
                        V.row(idx) = tempRowV;
                    }
                }
            }

        } else {
            std::cout << "something wrong with offset_edges!" << std::endl;
            std::cout << "neighbours size:" << neighbours.size() << std::endl;
            exit(1);
        }
#endif
    }
}

Eigen::Vector2d
Prototype::getClosestPointFromEdge(int vid, int evid0, int evid1, Eigen::MatrixXd& tempV)
{
    Eigen::Vector2d v0(1, 2), v1(1, 2), vp(1, 2), n;
    v0 = tempV.row(evid0);
    v1 = tempV.row(evid1);
    vp = tempV.row(vid);

    if ((vp - v0).dot(v1 - v0) <= 0) {
        return v0;
    } else if ((vp - v1).dot(v0 - v1) <= 0) {
        return v1;
    }

    n = (v1 - v0).normalized();
    double n0, n1, t, m0, m1;
    n0 = n(0);
    n1 = n(1);
    m0 = (v0 - vp).x();
    m1 = (v0 - vp).y();
    t = -(m0 * n0 + m1 * n1) / (n1 * n1 + n0 * n0);
    return v0 + n * t;
}

Eigen::Vector2d Prototype::getClosestPointOnInput(int vid, Eigen::MatrixXd& tempV, bool global)
{
    Eigen::Vector2d ret, v0(tempV(vid, 0), tempV(vid, 1));
    double closest = 99999;
    std::vector<std::vector<int>> A, AF;
    getAdjList(A);
    getAdjFaces(AF);
    const std::vector<int>& neighbours = A[vid];
    const std::vector<int>& neighbour_faces = AF[vid];

    if (global) {
        // global
        for (int i = 0; i < markedE.size(); ++i) {
            int evid0, evid1;
            evid0 = markedE[i][0];
            evid1 = markedE[i][1];
            bool isNeighbour = false;
            for (const int nvid : neighbours) {
                if (nvid == evid0) {
                    isNeighbour = true;
                    break;
                } else if (nvid == evid1) {
                    std::swap(evid0, evid1);
                    isNeighbour = true;
                    break;
                }
            }
            if (!isNeighbour) continue;

            Eigen::Vector2d temp = getClosestPointFromEdge(vid, evid0, evid1, tempV);
            if ((temp - v0).norm() < closest) {
                closest = (temp - v0).norm();
                ret = temp;
            }
        }
    } else {
        // local
        for (int i = 0; i < neighbour_faces.size(); ++i) {
            int vid0, vid1, tar_vid;
            vid0 = F(neighbour_faces[i], 0);
            vid1 = F(neighbour_faces[i], 1);
            tar_vid = F(neighbour_faces[i], 2);
            if (vid0 == vid) std::swap(vid0, tar_vid);
            if (vid1 == vid) std::swap(vid1, tar_vid);

            Eigen::Vector2d temp;
            if (isMarked(vid0, vid1)) {
                temp = getClosestPointFromEdge(vid, vid0, vid1, tempV);
            } else if (isMarked(vid0)) {
                temp = Eigen::Vector2d(tempV(vid0, 0), tempV(vid0, 1));
            } else if (isMarked(vid1)) {
                temp = Eigen::Vector2d(tempV(vid1, 0), tempV(vid1, 1));
            }

            if ((temp - v0).norm() < closest) {
                closest = (temp - v0).norm();
                ret = temp;
            }
        }
    }

    return ret;
}

bool Prototype::recomputeOffset(
    Eigen::Vector2d nv0,
    Eigen::Vector2d nv1,
    Eigen::Vector2d& newv,
    Eigen::Vector2d oldv,
    Eigen::Vector2d ov)
{
    Eigen::Vector2d ret;

    Eigen::Vector2d n = (newv - ov).normalized();
    double k0 = (oldv.y() - nv0.y()) / (oldv.x() - nv0.x());
    double k1 = (oldv.y() - nv1.y()) / (oldv.x() - nv1.x());
    // one side
    double t0 = (k0 * (ov.x() - nv0.x()) + (nv0.y() - ov.y())) / (n.y() - k0 * n.x());
    // another side
    double t1 = (k1 * (ov.x() - nv1.x()) + (nv1.y() - ov.y())) / (n.y() - k1 * n.x());

    double t = -1;

    if (t0 * t1 > 0) {
        t = std::min(t0, t1);
    } else {
        t = std::max(t0, t1);
    }

    if (t > 0 && t < 10) {
        newv = ov + t * n;
        // std::cout << t << std::endl;
    } else {
        return false;
    }

    return true;
}

void Prototype::remesh_project_to_input()
{
    igl::edges(F, E);
    P.resize(offset.size(), 2);
    for (int i = 0; i < P.rows(); ++i) {
        Eigen::Vector2d pro_p = getClosestPointOnInput(offset[i], V, true);
        P(i, 0) = pro_p.x();
        P(i, 1) = pro_p.y();
    }
}