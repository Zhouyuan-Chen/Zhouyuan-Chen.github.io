#pragma once
#include <igl/adjacency_list.h>
#include <igl/avg_edge_length.h>
#include <igl/boundary_loop.h>
#include <igl/collapse_edge.h>
#include <igl/doublearea.h>
#include <igl/edge_lengths.h>
#include <igl/edge_topology.h>
#include <igl/edges.h>
#include <igl/massmatrix.h>
#include <igl/triangle/triangulate.h>
#include <igl/writeOBJ.h>
#include <fstream>
#include <iostream>
#include <paraviewo/HDF5VTUWriter.hpp>
#include <string>
#include <vector>

/*
 * @brief Do inlation in 2D case
 * @param
 * @return
 */

class Prototype
{
public:
    Prototype(Eigen::MatrixXd V_, Eigen::MatrixXi E_)
        : V(V_)
        , E(E_)
    {
        P.resize(0, 0);
        F.setZero();
        offset.clear();
        offset_edges.clear();
        for (int i = 0; i < E.rows(); ++i) {
            int v0, v1;
            v0 = E(i, 0);
            v1 = E(i, 1);
            if (v0 > v1) std::swap(v0, v1);
            std::vector<int> temp;
            temp.push_back(v0);
            temp.push_back(v1);
            markedE.push_back(temp);
        }
        for (int i = 0; i < V.rows(); ++i) {
            markedV.push_back(i);
        }
        Eigen::MatrixXd newV(V.rows() + 4, V.cols());
        newV << V, -8, -8, -8, 8, 8, 8, 8, -8;
        V = newV;
        Eigen::MatrixXi newedge(E.rows() + 4, E.cols());
        int vid0 = V.rows() - 4, vid1 = V.rows() - 3, vid2 = V.rows() - 2, vid3 = V.rows() - 1;
        newedge << E, vid0, vid1, vid1, vid2, vid2, vid3, vid3, vid0;
        E = newedge;
    }
    void setVF(Eigen::MatrixXd V_, Eigen::MatrixXi E_)
    {
        V = V_;
        E = E_;

        F.setZero();
        offset.clear();
        offset_edges.clear();
        markedE.clear();
        markedV.clear();

        for (int i = 0; i < E.rows(); ++i) {
            int v0, v1;
            v0 = E(i, 0);
            v1 = E(i, 1);
            if (v0 > v1) std::swap(v0, v1);
            std::vector<int> temp;
            temp.push_back(v0);
            temp.push_back(v1);
            markedE.push_back(temp);
        }
        for (int i = 0; i < V.rows(); ++i) {
            markedV.push_back(i);
        }
        Eigen::MatrixXd newV(V.rows() + 4, V.cols());
        newV << V, -8, -8, -8, 8, 8, 8, 8, -8;
        V = newV;
        Eigen::MatrixXi newedge(E.rows() + 4, E.cols());
        int vid0 = V.rows() - 4, vid1 = V.rows() - 3, vid2 = V.rows() - 2, vid3 = V.rows() - 1;
        newedge << E, vid0, vid1, vid1, vid2, vid2, vid3, vid3, vid0;
        E = newedge;
    }

    enum RESOLUTION_LEVEL { LOW, MED, HIGH };
    enum FLIP_METHOD { EQUALIZED, MEANRATIO };
    enum SplitType { GENERAL, OFFSET, INTERIOR, BOUNDARY };
    void process(RESOLUTION_LEVEL level = MED);
    void remesh(
        double inflation_rate = 0.5,
        int iteration_time = 5,
        double len = -1,
        FLIP_METHOD method = EQUALIZED);
    void export_file(std::string path, bool need_obj = false, double padding_max_value = 5.0);

    // V,F is for operation, V2,F2 is for recording original data
    Eigen::MatrixXd V, V2;
    Eigen::MatrixXi F, F2;
    // boundary points and the edges
    Eigen::MatrixXi E, boundary;
    // project points
    Eigen::MatrixXd P;
    std::vector<std::pair<int, int>> boundary_edges;
    // record V along with original edges(may be splited)
    std::vector<int> markedV;
    // record edges(may be splited)
    std::vector<std::vector<int>> markedE;
    // record inlation vertex_id
    std::vector<int> offset;
    // record inlation-vertex-related edges
    std::vector<std::vector<int>> offset_edges;

    // private:
    void triangulate(RESOLUTION_LEVEL level);
    void inflate();

    //*****************************
    // basic topology operation
    //*****************************
    //       v3
    //       /\  f1
    //      /  \
    //  v1 /_e0_\ v2
    //     \    /
    //      \  /
    //       \/  f2
    //       v4
    // temporary operation, later would be replaced by toolkit's API
    // this is for edge
    int split(int vid0, int vid1, SplitType type);
    int split_general(int vid0, int vid1);
    int split_offset(int vid0, int vid1);
    int split_interior(int vid0, int vid1);
    int split_boundary(int vid0, int vid1);
    // temporary operation, later would be replaced by toolkit's API
    // this is for face
    int splitface(int fid);
    void get_target_edge_topology(
        int& vid1_,
        int& vid2_,
        int& vid3_,
        int& vid4_,
        int& fid1_,
        int& fid2_);
    void flip(int& vid1, int& vid2);
    void flip(int& vid1_, int& vid2_, int& vid3_, int& vid4_, int& fid1_, int& fid2_);
    int valence(int vid, const std::vector<std::vector<int>>& adj);
    int target_valence(int vid);
    double get_mean_ratio_vaule(int vid0, int vid1, int vid2, int vid3);
    // vid0 collapses to vid1
    bool collapse(int vid0, int vid1, double high);
    bool isInvert();
    // for project
    Eigen::Vector2d getClosestPointFromEdge(int vid, int evid0, int evid1, Eigen::MatrixXd& tempV);
    Eigen::Vector2d getClosestPointOnInput(int vid, Eigen::MatrixXd& tempV, bool global = true);
    bool recomputeOffset(
        Eigen::Vector2d nv0,
        Eigen::Vector2d nv1,
        Eigen::Vector2d& newv,
        Eigen::Vector2d oldv,
        Eigen::Vector2d ov);
    //*****************************
    // inflation part function
    //*****************************
    // for vertex
    bool isMarked(int idx);
    // for edge
    bool isMarked(int vid0, int vid1);
    // for vertex
    bool onOffset(int vid);
    // for edge
    bool onOffset(int vid0, int vid1);
    // for search
    bool isExist(const std::vector<int>& list, int idx);
    bool isExist(const Eigen::MatrixXi& list, int idx);
    // to visulize offset vertices
    void connectOffset();
    // fix offset update
    void updateBoundary();
    bool onBoundary(int vid0);
    bool onBoundary(int vid0, int vid1);
    void getAdjList(std::vector<std::vector<int>>& adjs_list);
    void getAdjFaces(std::vector<std::vector<int>>& adjs_list);
    bool
    onTheSameFace(const std::vector<std::vector<int>>& adjs_list, int tar_vid, int vid0, int vid1);
    bool
    isIntersect(Eigen::Vector2d l0p, Eigen::Vector2d l0q, Eigen::Vector2d l1p, Eigen::Vector2d l1q);
    bool needInvertNormal(Eigen::Vector2d mid, Eigen::Vector2d ori, std::vector<int> A);

    //*****************************
    // remesh part function
    //*****************************
    void remesh_split(double low);
    void remesh_collapse(double low, double high);
    void remesh_flip(FLIP_METHOD method);
    void remesh_relocate(double distance, int interation_time = 5);
    void remesh_project_to_input();
};