#include <igl/edge_flaps.h>
#include <igl/edges.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/readOBJ.h>
#include <igl/readOFF.h>
#include <igl/triangle/triangulate.h>
#include <igl/unproject_onto_mesh.h>
#include <embedded_remeshing/Inflation.hpp>
#include <fstream>
#include <iostream>

Eigen::MatrixXd V_Plane, V;
Eigen::MatrixXi F_Plane, F;
Eigen::MatrixXi E;
Eigen::MatrixXd inner_V;
Eigen::MatrixXi inner_E;
Eigen::MatrixXd inflation_V;
Eigen::MatrixXi inflation_E;
bool mode; // 0-off 1-on
bool has_new_data;
const std::string path = "D:\\";
Prototype* proto;

void generateDatawithSmallTriangles(Eigen::MatrixXd& V, Eigen::MatrixXi& E)
{
    V.resize(10, 2);
    E.resize(10, 2);
    V << 3.68892, 4.69909, 3.72799, -2.02109, 3.66695, -1.08875, -1.64113, 3.15912, -1.72872,
        2.57591, 1.20228, 4.31211, 2.19108, -0.595569, 2.78527, -0.139927, -4.85534, 0.28489,
        -4.68596, 3.57936;
    E << 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 0;
}
void generateDataSpecifiicCase(Eigen::MatrixXd& V, Eigen::MatrixXi& E)
{
    V.resize(12, 2);
    E.resize(12, 2);
    V << 0, 0, 1, 0, 1, 1, 0, 1, -1, -1, 2, -1, 2, 2, -1, 2, -3, -3, -3, 4, 4, 4, 4, -3;
    E << 0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 8, 9, 9, 10, 10, 11, 11, 8;
}
void generateStandardVoronoi(Eigen::MatrixXd& V, Eigen::MatrixXi& E)
{
    V.resize(8, 2);
    E.resize(8, 2);
    V << -5., 0., 0., 5., 5., 0., 0., -5., -5., -5., -5., 5., 5., 5., 5., -5.;
    E << 0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4;
}
void getVoronoiFromfile(const char* path, Eigen::MatrixXd& V, Eigen::MatrixXi& E)
{
    std::vector<std::pair<double, double>> edge_vertex_data;
    std::vector<std::pair<double, double>> vertices;
    std::vector<std::pair<int, int>> edges;

    std::ifstream in(path);

    if (!in.is_open()) {
        std::cout << "OPEN FAIL! --- " << path << std::endl;
        exit(1);
    }

    double x0, y0, x1, y1;
    in >> x0;
    while (!in.eof()) {
        in >> y0 >> x1 >> y1;
        edge_vertex_data.push_back(std::pair<double, double>(x0, y0));
        edge_vertex_data.push_back(std::pair<double, double>(x1, y1));
        in >> x0;
    }
    in.close();

    int edge_num, vertices_num;
    edge_num = edge_vertex_data.size();

    auto checkExist = [](std::vector<std::pair<double, double>>& table,
                         std::pair<double, double>& element) {
        int idx = 0;
        for (const auto ele : table) {
            if ((ele.first == element.first) && (ele.second == element.second)) return idx;
            if ((ele.first == element.first) && (ele.second == element.second)) return idx;
            idx++;
        }
        return -1;
    };

    for (int i = 0; i < edge_vertex_data.size() / 2; ++i) {
        std::pair<double, double> p0 = edge_vertex_data[i * 2];
        std::pair<double, double> p1 = edge_vertex_data[i * 2 + 1];
        if (checkExist(vertices, p0) == -1) {
            vertices.push_back(p0);
        }
        if (checkExist(vertices, p1) == -1) {
            vertices.push_back(p1);
        }
    }

    for (int i = 0; i < edge_vertex_data.size() / 2; ++i) {
        std::pair<double, double> p0 = edge_vertex_data[i * 2];
        std::pair<double, double> p1 = edge_vertex_data[i * 2 + 1];
        int p0_idx = checkExist(vertices, p0);
        int p1_idx = checkExist(vertices, p1);
        edges.push_back(std::pair<int, int>(p0_idx, p1_idx));
    }

    V.resize(vertices.size(), 2);
    E.resize(edges.size(), 2);

    for (int i = 0; i < vertices.size(); ++i) {
        V(i, 0) = vertices[i].first;
        V(i, 1) = vertices[i].second;
    }
    for (int i = 0; i < edges.size(); ++i) {
        E(i, 0) = edges[i].first;
        E(i, 1) = edges[i].second;
    }
}

void getResultCurve(Prototype& prototype)
{
    const std::vector<int>& markedV = prototype.markedV;
    const std::vector<std::vector<int>>& markedE = prototype.markedE;
    const std::vector<int>& offsetV = prototype.offset;
    const std::vector<std::vector<int>>& offsetE = prototype.offset_edges;

    inner_V.resize(markedV.size(), 2);
    inner_E.resize(markedE.size(), 2);
    inflation_V.resize(offsetV.size(), 2);
    inflation_E.resize(offsetE.size(), 2);

    std::vector<int> idxmap(markedV.size(), 0);

    for (int i = 0; i < markedV.size(); ++i) {
        inner_V.row(i) = prototype.V.row(markedV[i]);
        idxmap[markedV[i]] = i;
    }

    int offset = markedV.size();
    for (int i = 0; i < offsetV.size(); ++i) {
        inflation_V.row(i) = prototype.V.row(offsetV[i]);
        idxmap[offsetV[i]] = i + offset;
    }

    for (int i = 0; i < markedE.size(); ++i) {
        int idx0, idx1;
        idx0 = idxmap[markedE[i][0]];
        idx1 = idxmap[markedE[i][1]];
        inner_E.row(i) = Eigen::RowVector2i(idx0, idx1);
    }

    for (int i = 0; i < offsetE.size(); ++i) {
        int idx0, idx1;
        idx0 = idxmap[offsetE[i][0]];
        idx1 = idxmap[offsetE[i][1]];
        inflation_E.row(i) = Eigen::RowVector2i(idx0, idx1);
    }

    std::cout << "getCarve Finished" << std::endl;
}

bool key_down(igl::opengl::glfw::Viewer& viewer, unsigned char key, int modifier)
{
    std::cout << "Key: " << key << " " << (unsigned int)key << std::endl;
    if (key == '1') {
        mode = !mode;

        if (mode == false) {
            has_new_data = false;
            proto = new Prototype(V, E);
        }
    } else if (key == '2') {
        // draw plane
        // H.resize(1, 2);
        // Eigen::VectorXi VM, EM, VM2, EM2;
        // create two squares, one with edge length of 4,
        // one with edge length of 2
        // both centered at origin
        // V.resize(2, 2);
        // E.resize(1, 2);
        // V << 1, 0, 2, 0;
        // E << 0, 1;

        if (V.rows() == 0) return false;
        if (proto == nullptr) return false;

        // generateDatawithSmallTriangles(V, E);
        proto->process();
        // getResultCurve(proto);
        viewer.data().clear();

        // visualize the infaltion vertices
        auto temp = proto->offset;
        for (int i : temp) {
            viewer.data().add_points(proto->V.row(i), Eigen::RowVector3d(1, 0, 0));
        }
        // visualize the inner vertices
        temp = proto->markedV;
        for (int i : temp) {
            viewer.data().add_points(proto->V.row(i), Eigen::RowVector3d(0, 1, 0));
        }
        // visualize the inflation edges(surfaces in 3D)
        auto temp_edges = proto->offset_edges;
        for (auto e : temp_edges) {
            viewer.data().add_edges(
                proto->V.row(e[0]),
                proto->V.row(e[1]),
                Eigen::RowVector3d(1, 0, 0));
        }
        // visualize the original edges
        temp_edges = proto->markedE;
        for (auto e : temp_edges) {
            viewer.data().add_edges(
                proto->V.row(e[0]),
                proto->V.row(e[1]),
                Eigen::RowVector3d(1, 0, 0));
        }
        viewer.data().set_mesh(proto->V, proto->F);
        // proto->export_file(path);
    } else if (key == '3') {
        if (proto) proto->remesh();
        viewer.data().clear();

        // visualize the infaltion vertices
        auto temp = proto->offset;
        for (int i : temp) {
            viewer.data().add_points(proto->V.row(i), Eigen::RowVector3d(1, 0, 0));
        }
        // visualize the inner vertices
        temp = proto->markedV;
        for (int i : temp) {
            viewer.data().add_points(proto->V.row(i), Eigen::RowVector3d(0, 1, 0));
        }
        // visualize the inflation edges(surfaces in 3D)
        auto temp_edges = proto->offset_edges;
        for (auto e : temp_edges) {
            viewer.data().add_edges(
                proto->V.row(e[0]),
                proto->V.row(e[1]),
                Eigen::RowVector3d(1, 0, 0));
        }
        // visualize the original edges
        temp_edges = proto->markedE;
        for (auto e : temp_edges) {
            viewer.data().add_edges(
                proto->V.row(e[0]),
                proto->V.row(e[1]),
                Eigen::RowVector3d(1, 0, 0));
        }
        viewer.data().set_mesh(proto->V, proto->F);

    } else if (key == '4') {
        if (proto == nullptr) return false;
        std::cout << "export file..." << std::endl;
        proto->export_file(path);
        std::cout << "done!" << std::endl;
    } else if (key == '5') {
        if (proto) {
            delete proto;
            proto = nullptr;
        }
        // get a plane
        V.resize(0, 2);
        E.resize(0, 2);
        V_Plane.resize(4, 3);
        F_Plane.resize(2, 3);
        V_Plane << -5, -5, 0, -5, 5, 0, 5, -5, 0, 5, 5, 0;
        F_Plane << 0, 2, 1, 2, 3, 1;
        viewer.data().clear();
        viewer.data().set_mesh(V_Plane, F_Plane);
    }

    return false;
}

int main(int argc, char* argv[])
{
    std::cout << R"(
1 Switch On/Off to Line-Drawing Mode (Please Switch Off the Line-Drawing Mode First!)
2 Embedded Meshing (Please Switch Off the Line-Drawing Mode First!)
3 Embedded Meshing (Please Switch Off the Line-Drawing Mode First!)
4 Extract Meshing (Please Switch Off the Line-Drawing Mode First!)
5 Reset (Please Switch Off the Line-Drawing Mode First!)
    )";

    mode = false;
    has_new_data = false;

    // Initialize the Viewer
    igl::opengl::glfw::Viewer viewer;

    // get a plane
    V_Plane.resize(4, 3);
    F_Plane.resize(2, 3);
    V_Plane << -5, -5, 0, -5, 5, 0, 5, -5, 0, 5, 5, 0;
    F_Plane << 0, 2, 1, 2, 3, 1;

    // Mouse interaction
    viewer.callback_mouse_down = [](igl::opengl::glfw::Viewer& viewer, int, int) -> bool {
        if (!mode) return false;
        int fid;
        Eigen::Vector3f bc;
        // Cast a ray in the view direction starting from the mouse position
        double x = viewer.current_mouse_x;
        double y = viewer.core().viewport(3) - viewer.current_mouse_y;
        if (igl::unproject_onto_mesh(
                Eigen::Vector2f(x, y),
                viewer.core().view,
                viewer.core().proj,
                viewer.core().viewport,
                V_Plane,
                F_Plane,
                fid,
                bc)) {
            auto v0 = V_Plane.row(F_Plane(fid, 0)), v1 = V_Plane.row(F_Plane(fid, 1)),
                 v2 = V_Plane.row(F_Plane(fid, 2));
            double p_x = v0(0, 0) * bc[0] + v1(0, 0) * bc[1] + v2(0, 0) * bc[2];
            double p_y = v0(0, 1) * bc[0] + v1(0, 1) * bc[1] + v2(0, 1) * bc[2];
            double p_z = v0(0, 2) * bc[0] + v1(0, 2) * bc[1] + v2(0, 2) * bc[2];

            Eigen::MatrixXd newV(V.rows() + 1, 2);
            Eigen::MatrixXi newE(E.rows() + 1, 2);
            newV << V, p_x, p_y;
            V = newV;

            if (V.rows() > 1) {
                newE << E, E.rows(), E.rows() + 1;
                E = newE;
            }
            viewer.data().add_points(
                Eigen::RowVector3d(p_x, p_y, p_z),
                Eigen::RowVector3d(0, 0, 1));
            // paint hit red
            // C.row(fid) << 1, 0, 0;
            // viewer.data().set_colors(C);
            if (has_new_data = false) has_new_data = true;

            return true;
        }
        return false;
    };

    // std::ifstream in("..\\..\\voronoi_dataset\\vertex_num_5\\data0");
    // double x0, y0, x1, y1;
    // in >> x0;
    // while (!in.eof()) {
    //     in >> y0 >> x1 >> y1;
    //     viewer.data().add_edges(
    //         Eigen::RowVector3d(x0, y0, 0),
    //         Eigen::RowVector3d(x1, y1, 0),
    //         Eigen::RowVector3d(1, 0, 0));
    //     in >> x0;
    // }
    // in.close();

    // generateDatawithSmallTriangles(V, E);
    // generateDataSpecifiicCase(V, E);
    // getVoronoiFromfile("..\\..\\voronoi_dataset\\inputs\\vertex_num_10\\data9", V, E);

    //  Prototype instance(V, E);
    // instance.process();
    // instance.remesh(5.0, 20);
    // viewer.data().set_mesh(instance.V, instance.F);
    // instance.export_file(path, true);
    // igl::readOBJ(path + "result_inflation.obj", V, F);

    proto = nullptr;
    viewer.data().set_mesh(V_Plane, F_Plane);
    viewer.callback_key_down = &key_down;
    viewer.data().set_face_based(true);
    viewer.launch();
}