---
title: "Simulation"
excerpt: "Simulation Learning<br/><img src='/images/simulation.png' width='40%'>"
collection: portfolio
---

## Simulation

With online tutorial(tenMinutePhysics/CSC417-physics-based-animation), I self-schooled some simulation stuff, FEM and fluid simulation.

Actually, this field is harder than I thought. I spent too much time on reading related materials and figuring out what is happening for the formula and the algorithms, LOL.

<img decoding="async" src="/images/simulation.png" width="50%">

<img decoding="async" src="/images/simulation1.png" width="50%">
