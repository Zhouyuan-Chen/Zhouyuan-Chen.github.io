---
title: "Geometry Processing"
excerpt: "Geometry Processing Learning<br/><img src='/images/subdivide.png' width='30%'>"
collection: portfolio
---

I self-schooled a Geometry Processing course and finished the assignment, and this course definitely broaden my horrizons. I then decided to do more work on some fields related to Geometry Processing.

## Smoothing

<img decoding="async" src="/images/smoothing.png">

## Reconstruction

<img decoding="async" src="/images/reconstruction.png" width="50%">

## Parameterization

| | | |
|-- | -- | -- |
|<img decoding="async" src="/images/parameterization00.png"> | <img decoding="async" src="/images/parameterization10.png">|<img decoding="async" src="/images/parameterization11.png"> |
|<img decoding="async" src="/images/parameterization00.png"> | <img decoding="async" src="/images/parameterization20.png">|<img decoding="async" src="/images/parameterization21.png"> |

## Deformation

This part's results are missed...
