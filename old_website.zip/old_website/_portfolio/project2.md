---
title: "Rendering Engine Toy"
excerpt: "Global Illumination Learning<br/><img src='/images/rt3.png' width='40%'>"
collection: portfolio
---

## Rendering Engine Toy

In this project, I read three handy books written by Peter Shirley and implemented the basic raytracying rendering engine step by step. After that, I read the book Advanced Global Illumination in order to get more details.

I think this should be my first time getting in touch with the real Computer Graphics.

See more results by checking following link!

[-- Results Link --](https://github.com/Zhouyuan-Chen/RayTracingInOneWeek)

<img decoding="async" src="/images/rt3.png" width="100%">

<img decoding="async" src="/images/rt0.png" width="100%">

<img decoding="async" src="/images/rt1.png" width="100%">

<img decoding="async" src="/images/rt2.png" width="100%">