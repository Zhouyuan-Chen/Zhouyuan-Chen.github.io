---
title: "Something Cool on Shadertoy"
excerpt: "Noise Learning<br/><img src='/images/shadertoy.png' width='20%'>"
collection: portfolio
---

 Noises can be the amazing stuff. I have to admitted that I can watch the noise images for a really long time. Later, I did a small research on noises. It surprised me that noises can generate almost anything complicated in our world, sea wave, moutains or even cloud!

 Following two are my practices on FBM.

<iframe width="640" height="360" frameborder="0" src="https://www.shadertoy.com/embed/fs3cRn?gui=true&t=10&paused=true&muted=false" allowfullscreen></iframe>

<iframe width="640" height="360" frameborder="0" src="https://www.shadertoy.com/embed/Nd3cR4?gui=true&t=10&paused=true&muted=false" allowfullscreen></iframe>
