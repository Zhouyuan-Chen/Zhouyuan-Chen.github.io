---
title: "Mini Games"
excerpt: "A Game Collection that you can play! <br/><img src='/images/game1.png' width='40%'>"
collection: portfolio
---

## Mini Games

there are some mini games that can kill time, hope you can enjoy them

- Game List
- - flappy bird
- - Game of Life
- - Arkanoid
- - Airplane War
- - Snake
- - Bravely enter the 100th floor of the basement
- - FIFA

[-- Download Link --](https://github.com/Zhouyuan-Chen/MyGames) 

I spent a summer with my friend made the game FIFA when we were first year college students, we even made a simple UI for players to choose a country and log their accounts. 

<img decoding="async" src="/images/game1.png" width="100%">

