---
#title: "direct physical simulation from annotated images"
title: "will update later"
collection: publications
permalink: /publication/2009-10-01-paper-title-number-1
excerpt: #'Will Update Later'
date: 2024-01-23
venue: 'arxiv'
paperurl: #'http://academicpages.github.io/files/paper1.pdf'
citation: #'Your Name, You. (2009). &quot;Paper Title Number 1.&quot; <i>Journal 1</i>. 1(1).'
---
will update later...
