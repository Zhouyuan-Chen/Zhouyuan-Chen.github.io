---
title: "CSCI-GA.3033-018: Geometric Modelling(graduate course)"
collection: teaching
type: "Teaching Assistant"
permalink: /teaching/teaching2
venue: "New York University, Department of Computer Science"
date: 2024-01-22
location: "New York City, United States"
---
