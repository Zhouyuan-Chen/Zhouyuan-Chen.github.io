---
title: "CSCI-UA 101: Intro to Computer Science(undergraduate course)"
collection: teaching
type: "Grader"
#permalink: /teaching/teaching1
venue: "New York University, Department of Computer Science"
date: 2024-01-22
location: "New York City, United States"
---
